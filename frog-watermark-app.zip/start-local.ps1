param(
    [string]$Python = "D:\AIProjects\watermark-removal\.venv\Scripts\python.exe",
    [string]$Weights = "D:\AIProjects\watermark-removal\runs\slbr-fourier-v1\best-weights.pt",
    [ValidateSet("auto", "cuda", "cpu")][string]$Device = "cuda",
    [int]$Port = 8080
)
$ErrorActionPreference = "Stop"
Set-Location -LiteralPath $PSScriptRoot
if (-not (Test-Path -LiteralPath $Python)) { throw "Python not found. Use -Python to provide the existing virtual environment interpreter." }
if (-not (Test-Path -LiteralPath $Weights)) { throw "Weights not found. Use -Weights to provide best-weights.pt." }
Write-Host "After startup, open http://127.0.0.1:$Port . Press Ctrl+C to stop."
& $Python -m wmr.web --weights $Weights --device $Device --port $Port
if ($LASTEXITCODE -ne 0) { throw "Application stopped with an error. See the message above." }
