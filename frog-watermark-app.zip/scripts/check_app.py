"""Optional focused integration check, using a real exported checkpoint.

This checks plumbing and numerical consistency, NOT watermark removal quality.
"""
import argparse
import io
import json
from pathlib import Path
import sys
import time

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import numpy as np
from PIL import Image, ImageDraw
from fastapi.testclient import TestClient
from wmr.web import create_app


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--weights', required=True)
    p.add_argument('--device', default='cpu')
    p.add_argument('--output', default='reports/release-check.json')
    args = p.parse_args()
    im = Image.new('RGB', (384, 256), '#e3e9dc')
    d = ImageDraw.Draw(im)
    for x in range(0, 384, 24):
        d.line((x, 0, 384-x, 255), fill='#557b8a', width=2)
    d.rectangle((105, 83, 290, 153), fill='#b3b298')
    d.text((125, 109), 'AUTHORIZED TEST', fill='#333333')
    b = io.BytesIO()
    im.save(b, 'PNG')
    app = create_app(args.weights, device=args.device)
    observations = {}
    report = {'fixture': 'synthetic pipeline fixture; not quality evaluation'}
    with TestClient(app) as c:
        headers = {}
        import os
        if os.environ.get('WMR_ACCESS_TOKEN'):
            headers['X-Access-Token'] = os.environ['WMR_ACCESS_TOKEN']
        def observe_fourier(module, inputs, output):
            observations['fourier_input'] = list(inputs[0].shape)
            observations['fourier_output'] = list(output.shape)
            observations['fourier_max_abs_residual'] = float((output-inputs[0]).abs().max())
        handle = app.state.predictor.model.refinement.fourier.register_forward_hook(observe_fourier)
        assert c.get('/').status_code == 200
        assert c.get('/api/health').json()['ready']
        assert c.post('/api/jobs', content=b'invalid', headers=headers).status_code == 422
        submitted = c.post('/api/jobs', content=b.getvalue(), headers=headers)
        assert submitted.status_code == 202, submitted.text
        job_id = submitted.json()['id']
        deadline = time.monotonic() + 90
        while time.monotonic() < deadline:
            job = c.get('/api/jobs/' + job_id, headers=headers).json()
            if job['status'] in {'succeeded', 'failed'}:
                break
            time.sleep(.1)
        assert job['status'] == 'succeeded', job
        result_response = c.get(job['result_url'], headers=headers)
        assert result_response.status_code == 200
        result = Image.open(io.BytesIO(result_response.content))
        assert result.size == im.size
        original = Image.open(io.BytesIO(c.get(job['original_url'], headers=headers).content))
        assert np.array_equal(np.array(original), np.array(im))
        direct, _ = app.state.predictor.process(app.state.work_root / job_id / 'original.png')
        assert np.array_equal(np.array(result), np.array(direct))
        download = c.get(job['download_url'], headers=headers)
        assert download.status_code == 200 and 'attachment' in download.headers['content-disposition']
        assert c.get('/weights/best-weights.pt').status_code == 404
        handle.remove()
        assert observations['fourier_input'] == [1, 128, 64, 64]
        assert observations['fourier_max_abs_residual'] > 0
        assert app.state.load_count == 1
        assert c.delete('/api/jobs/' + job_id, headers=headers).status_code == 204
        assert c.get('/api/jobs/' + job_id, headers=headers).status_code == 404
        import fastapi, starlette, uvicorn, torch
        report.update({'versions': {'fastapi': fastapi.__version__, 'starlette': starlette.__version__, 'uvicorn': uvicorn.__version__, 'torch': torch.__version__},
                       'device': str(app.state.predictor.device), 'model_load_count': 1,
                       'fourier': observations, 'web_vs_predictor_pixel_equal': True,
                       'result_dimensions_preserved': True, 'invalid_image_rejected': True,
                       'download': True, 'cleanup': True, 'weights_not_public': True,
                       'stats': job['stats'], 'browser_qa': 'not run: managed preview unavailable',
                       'quality_evaluation': 'not run: paired dataset not supplied'})
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, indent=2, ensure_ascii=False))
    print(json.dumps(report, indent=2, ensure_ascii=False))


if __name__ == '__main__':
    main()
