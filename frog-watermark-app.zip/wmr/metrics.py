import torch
from torch.nn import functional as F


def final_image(outputs, image):
    predicted_mask = outputs[1][0]
    return (outputs[0][0] * predicted_mask + image * (1 - predicted_mask)).clamp(0, 1)


def ssim(x, y):
    # RGB, 11x11 Gaussian sigma=1.5, valid convolution, range [0,1].
    axis = torch.arange(11, device=x.device, dtype=x.dtype) - 5
    g = torch.exp(-(axis**2) / (2 * 1.5**2))
    g = g / g.sum()
    kernel = (g[:, None] * g[None, :]).expand(3, 1, 11, 11)
    conv = lambda z: F.conv2d(z, kernel, groups=3)
    ux, uy = conv(x), conv(y)
    vx, vy = conv(x*x)-ux*ux, conv(y*y)-uy*uy
    cov = conv(x*y)-ux*uy
    score = ((2*ux*uy+.01**2)*(2*cov+.03**2)) / ((ux*ux+uy*uy+.01**2)*(vx+vy+.03**2))
    return score.flatten(1).mean(1)


@torch.no_grad()
def evaluate_loader(model, loader, device):
    was_training = model.training
    model.eval()
    sums, counts = {}, {}
    def add(name, values):
        values = values[torch.isfinite(values)]
        sums[name] = sums.get(name, 0.) + values.sum().item()
        counts[name] = counts.get(name, 0) + values.numel()
    for batch in loader:
        x, y, m = (batch[k].to(device) for k in ("image", "target", "mask"))
        outputs = model(x)
        result = final_image(outputs, x)
        error = (result-y).square()
        add("psnr", -10*error.flatten(1).mean(1).clamp_min(1e-12).log10())
        add("ssim", ssim(result, y))
        for name, region in (("watermark_mae", m), ("background_mae", 1-m)):
            area = region.flatten(1).sum(1)*3
            value = ((result-y).abs()*region).flatten(1).sum(1)/area.clamp_min(1)
            add(name, value[area > 0])
        p = outputs[1][0] >= .5
        gt = m >= .5
        inter = (p & gt).flatten(1).sum(1).float()
        union = (p | gt).flatten(1).sum(1).float()
        add("mask_iou", (inter+1e-6)/(union+1e-6))
    model.train(was_training)
    return {name: sums[name]/counts[name] if counts[name] else None for name in sums}
