"""One bounded complete-model training/checkpoint/inference check, not effect evaluation."""
import argparse
import json
import math
import tempfile
import time
from pathlib import Path
import torch
from torch.utils.data import DataLoader, Subset
from .checkpoint import (make_optimizers, save_training, restore_training,
                         export_weights, load_export)
from .data import LogoDataset
from .losses import SLBRObjective
from .metrics import final_image
from .model import build_model, load_base_weights, PRECISION_POLICY


def run(args):
    torch.set_num_threads(4)
    device = torch.device(args.device)
    if device.type == "cuda":
        torch.cuda.reset_peak_memory_stats(device)
    model = build_model().to(device)
    initialization = load_base_weights(model, args.base_weights) if args.base_weights else "random debug initialization"
    objective = SLBRObjective().to(device).eval()
    optimizers = make_optimizers(model, 1e-3)
    schedulers = {k: torch.optim.lr_scheduler.MultiStepLR(o, [65], gamma=.1)
                  for k, o in optimizers.items()}
    scaler = torch.amp.GradScaler(device.type, enabled=device.type == "cuda", init_scale=256.0)
    if args.data_root:
        data = LogoDataset(args.data_root, args.manifest, args.size, training=True)
        batch = next(iter(DataLoader(Subset(data, range(min(args.batch, len(data)))), batch_size=args.batch)))
        x, y, mask = (batch[k].to(device) for k in ("image", "target", "mask"))
        origin = "real dataset sample via project loader"
    else:
        x = torch.rand(args.batch, 3, args.size, args.size, device=device)
        y = .9*x
        mask = torch.zeros(args.batch, 1, args.size, args.size, device=device)
        mask[:, :, args.size//4:args.size//2, args.size//4:args.size//2] = 1
        origin = "synthetic pipeline fixture; not actual LOGO training"
    observed = {}
    hooks = []
    def hook(name):
        def record(module, inputs, outputs):
            observed[name] = [list(t.shape) for t in outputs] if isinstance(outputs, (tuple, list)) else list(outputs.shape)
        return record
    for name, module in model.named_modules():
        if name.endswith("fourier") or name.startswith("refinement.cff_blocks.") and name.count(".")==2:
            hooks.append(module.register_forward_hook(hook(name)))
    start = time.perf_counter()
    amp_attempts = []
    # Only calibrate loss scaling, never replace NaNs or bypass a nonfinite loss.
    # Restore BN buffers for each retry so repeated attempts do not alter statistics.
    saved_buffers = {name: value.clone() for name, value in model.named_buffers()}
    for attempt in range(4):
        for name, value in model.named_buffers():
            value.copy_(saved_buffers[name])
        for optimizer in optimizers.values():
            optimizer.zero_grad(set_to_none=True)
        with torch.autocast(device.type, dtype=torch.float16, enabled=device.type == "cuda"):
            outputs = model(x)
        losses = objective(outputs, y, mask)
        if set(observed) != {"refinement.fourier", *(f"refinement.cff_blocks.{i}" for i in range(3))}:
            raise RuntimeError(f"Core module execution inventory mismatch: {observed}")
        if not all(torch.isfinite(value).all() for value in losses.values()):
            raise RuntimeError("Nonfinite forward/loss after precision fix; do not scale or sanitize it")
        scaler.scale(losses["total"]).backward()
        for optimizer in optimizers.values():
            scaler.unscale_(optimizer)
        bad = [name for name, param in model.named_parameters()
               if param.grad is not None and not torch.isfinite(param.grad).all()]
        amp_attempts.append({"scale": scaler.get_scale(), "nonfinite_gradient_keys": bad})
        if not bad:
            break
        if not scaler.is_enabled() or attempt == 3:
            raise RuntimeError(f"Nonfinite gradients after bounded scale calibration: {amp_attempts}")
        scaler.update()
        del outputs, losses
        print(f"AMP scale calibration retry: next_scale={scaler.get_scale()}", flush=True)
    missing = [n for n, p in model.named_parameters() if p.requires_grad and p.grad is None]
    expected = {n for n, _ in model.named_parameters()
                if ".refine_branch." in n or n.endswith(".self_calibrated.k_weight")}
    if set(missing) != expected:
        raise RuntimeError(f"Unexplained gradient inventory: missing={missing}, expected={sorted(expected)}")
    spectral_grad = {n: p.grad.norm().item() for n, p in model.refinement.fourier.named_parameters()}
    if not all(math.isfinite(v) and v > 0 for v in spectral_grad.values()):
        raise RuntimeError(f"Fourier branch not fully learning: {spectral_grad}")
    for o in optimizers.values():
        scaler.step(o)
    scaler.update()
    for s in schedulers.values():
        s.step()
    model.eval()
    with torch.no_grad():
        expected_output = final_image(model(x), x)
    # Snapshot optimizer states + all RNG states, and reload into same model.
    with tempfile.TemporaryDirectory() as temporary:
        root = Path(temporary)
        config, data = {"preflight": True}, {"fixture": origin}
        save_training(root/"last.pt", model, optimizers, schedulers, scaler, 1, 1, 0., config, data)
        restore_training(root/"last.pt", model, optimizers, schedulers, scaler, config, data)
        export_weights(model, root/"weights.pt")
        del outputs, losses
        load_export(model, root/"weights.pt", device)
        with torch.no_grad():
            actual = final_image(model(x), x)
        torch.testing.assert_close(expected_output, actual, rtol=0, atol=0)
        from .infer import Predictor
        predictor = Predictor(root/"weights.pt", str(device), args.size)
        from PIL import Image
        Image.new("RGB", (80, 64), (90, 100, 110)).save(root/"input.png")
        image, inference_stats = predictor.process(root/"input.png")
        assert image.size == (80, 64)
        image.save(root/"output.png")
    for h in hooks:
        h.remove()
    result = {"check": "preflight pipeline only", "input_origin": origin, "initialization": initialization,
              "precision_policy": PRECISION_POLICY, "amp_scale_attempts": amp_attempts,
              "device": str(device), "torch": torch.__version__, "input": list(x.shape),
              "parameters": sum(p.numel() for p in model.parameters()),
              "fourier_parameters": sum(p.numel() for p in model.refinement.fourier.parameters()),
              "observed": observed, "expected_unused_parameters": sorted(expected),
              "fourier_gradient_norms": spectral_grad, "strict_reload_equal": True,
              "standalone_predictor": inference_stats, "seconds": time.perf_counter()-start,
              "peak_allocated_mib": torch.cuda.max_memory_allocated()/1024**2 if device.type=="cuda" else None,
              "limitations": "Not training quality, not a model benchmark; peak includes extra reload/inference model."}
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    Path(args.output).write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--device", default="cuda")
    p.add_argument("--size", default=64, type=int, help="Debug only; not formal training resolution")
    p.add_argument("--batch", default=1, type=int)
    p.add_argument("--data-root")
    p.add_argument("--base-weights")
    p.add_argument("--manifest", default="data/splits/logo_multi_v1/train.csv")
    p.add_argument("--output", default="runs/preflight.json")
    run(p.parse_args())
