import csv
import hashlib
import random
from pathlib import Path
import numpy as np
import torch
from PIL import Image
from torch.utils.data import Dataset


def read_rgb(path):
    with Image.open(path) as im:
        im.load()
        if "A" in im.getbands() and im.getchannel("A").getextrema() != (255, 255):
            raise ValueError(f"Nonopaque alpha requires an explicit handling decision: {path}")
        return im.convert("RGB")


def to_tensor(im):
    arr = np.array(im, dtype=np.float32, copy=True)
    if arr.ndim == 2:
        arr = arr[:, :, None]
    return torch.from_numpy(arr.transpose(2, 0, 1).copy()) / 255.0


class LogoDataset(Dataset):
    def __init__(self, root, manifest, size=256, training=False, seed=20261021):
        self.root = Path(root).resolve()
        self.manifest = Path(manifest)
        with self.manifest.open(encoding="utf-8-sig", newline="") as f:
            self.rows = list(csv.DictReader(f))
        if not self.rows or size < 64 or size % 16:
            raise ValueError("Nonempty manifest and size multiple of 16, >=64 required")
        self.size, self.training, self.seed, self.epoch = size, training, seed, 0
        self.digest = hashlib.sha256(self.manifest.read_bytes()).hexdigest()

    def __len__(self):
        return len(self.rows)

    def __getitem__(self, index):
        row = self.rows[index]
        paths = {}
        for key in ("image", "natural", "mask"):
            path = (self.root / row[key]).resolve()
            if self.root not in path.parents:
                raise ValueError("Manifest path escapes data root")
            paths[key] = path
        image, target = read_rgb(paths["image"]), read_rgb(paths["natural"])
        with Image.open(paths["mask"]) as im:
            if im.mode != "L":
                raise ValueError(f"Expected L mask: {paths['mask']}")
            mask = im.copy()
        if len({image.size, target.size, mask.size}) != 1:
            raise ValueError(f"Misaligned dimensions: {row['source_id']}")
        if not set(mask.getdata()).issubset({0, 255}):
            raise ValueError(f"Nonbinary raw mask: {paths['mask']}")
        image = image.resize((self.size, self.size), Image.Resampling.BILINEAR)
        target = target.resize((self.size, self.size), Image.Resampling.BILINEAR)
        mask = mask.resize((self.size, self.size), Image.Resampling.NEAREST)
        # Deterministic per-sample/per-epoch augmentation, including after resume.
        rng = random.Random(f"{self.seed}:{self.epoch}:{row['source_id']}")
        if self.training and rng.random() < 0.5:
            image, target, mask = [im.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
                                   for im in (image, target, mask)]
        return {"image": to_tensor(image), "target": to_tensor(target),
                "mask": to_tensor(mask), "source_id": row["source_id"]}
