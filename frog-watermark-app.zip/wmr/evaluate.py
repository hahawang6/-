import argparse
import json
from pathlib import Path
import torch
from torch.utils.data import DataLoader
from .checkpoint import load_export
from .data import LogoDataset
from .metrics import evaluate_loader
from .model import build_model

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--weights", required=True)
    p.add_argument("--data-root", default="data/raw/LOGO-Multi")
    p.add_argument("--manifest", default="data/splits/logo_multi_v1/test.csv")
    p.add_argument("--output", default="runs/test_metrics.json")
    p.add_argument("--device", default="cuda")
    args = p.parse_args()
    device = torch.device(args.device)
    model = build_model().to(device)
    load_export(model, args.weights, device)
    dataset = LogoDataset(args.data_root, args.manifest, size=256)
    result = {"manifest_sha256": dataset.digest, "count": len(dataset),
              "protocol": "256x256 resized RGB; PSNR per-image mean; valid 11x11 Gaussian SSIM; predicted-mask output fusion",
              "metrics": evaluate_loader(model, DataLoader(dataset, batch_size=1), device)}
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    Path(args.output).write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))
