import hashlib
import json
import os
import random
from pathlib import Path
import numpy as np
import torch
from .model import REFERENCE_COMMIT


def make_optimizers(model, lr):
    return {name: torch.optim.Adam(getattr(model, name).parameters(), lr=lr,
                                   betas=(.9, .999), weight_decay=0)
            for name in ("encoder", "shared_decoder", "coarse_decoder", "refinement")}


def config_digest(config):
    return hashlib.sha256(json.dumps(config, sort_keys=True).encode()).hexdigest()


def atomic_save(obj, path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    torch.save(obj, temp)
    os.replace(temp, path)


def save_training(path, model, optimizers, schedulers, scaler, epoch, step, best, config, data):
    atomic_save({"format": "slbr-fourier-v1", "reference_commit": REFERENCE_COMMIT,
                 "model": model.state_dict(), "optimizers": {k: v.state_dict() for k, v in optimizers.items()},
                 "schedulers": {k: v.state_dict() for k, v in schedulers.items()},
                 "scaler": scaler.state_dict(), "next_epoch": epoch, "step": step,
                 "best_psnr": best, "config": config, "config_digest": config_digest(config),
                 "data": data, "rng_python": random.getstate(), "rng_numpy": np.random.get_state(),
                 "rng_torch": torch.get_rng_state(),
                 "rng_cuda": torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None}, path)


def restore_training(path, model, optimizers, schedulers, scaler, config, data):
    # Full training state contains NumPy/Python state; only load own trusted files.
    obj = torch.load(path, map_location="cpu", weights_only=False)
    if obj.get("format") != "slbr-fourier-v1" or obj["reference_commit"] != REFERENCE_COMMIT:
        raise ValueError("Unsupported training checkpoint")
    if obj["config_digest"] != config_digest(config) or obj["data"] != data:
        raise ValueError("Config/data changed: explicit migration required, not exact resume")
    model.load_state_dict(obj["model"], strict=True)
    if set(obj["optimizers"]) != set(optimizers) or set(obj["schedulers"]) != set(schedulers):
        raise ValueError("Optimizer/scheduler inventory mismatch")
    for k in optimizers:
        optimizers[k].load_state_dict(obj["optimizers"][k])
        schedulers[k].load_state_dict(obj["schedulers"][k])
    scaler.load_state_dict(obj["scaler"])
    random.setstate(obj["rng_python"])
    np.random.set_state(obj["rng_numpy"])
    torch.set_rng_state(obj["rng_torch"])
    if obj["rng_cuda"] is not None:
        torch.cuda.set_rng_state_all(obj["rng_cuda"])
    return obj["next_epoch"], obj["step"], obj["best_psnr"]


def export_weights(model, path):
    atomic_save({"format": "slbr-fourier-inference-v1", "reference_commit": REFERENCE_COMMIT,
                 "model": {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}}, path)


def load_export(model, path, device):
    obj = torch.load(path, map_location=device, weights_only=True)
    if obj.get("format") != "slbr-fourier-inference-v1" or obj.get("reference_commit") != REFERENCE_COMMIT:
        raise ValueError("Expected project's exported inference weights")
    model.load_state_dict(obj["model"], strict=True)
