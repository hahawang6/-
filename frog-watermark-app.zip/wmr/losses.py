"""Independently expressed training objective matched to fixed SLBR release code."""
import torch
from torch import nn
from torch.nn import functional as F
from torchvision.models import vgg16, VGG16_Weights


def relative_l1(pred, target, mask):
    # Reference sums RGB error / mask area, without division by channel count.
    numerator = ((pred - target).abs() * mask).flatten(1).sum(1)
    return (numerator / (mask.flatten(1).sum(1) + 1e-6)).mean()


class VGGObjective(nn.Module):
    def __init__(self):
        super().__init__()
        features = vgg16(weights=VGG16_Weights.IMAGENET1K_V1).features
        self.stages = nn.ModuleList([features[:5], features[5:10], features[10:17]])
        self.requires_grad_(False)
        self.register_buffer("mean", torch.tensor([.485, .456, .406]).view(1, 3, 1, 1))
        self.register_buffer("std", torch.tensor([.229, .224, .225]).view(1, 3, 1, 1))

    @staticmethod
    def gram(x):
        b, c, h, w = x.shape
        flat = x.reshape(b, c, h * w)
        return flat.bmm(flat.transpose(1, 2)) / (c * h * w)

    def forward(self, x, target):
        x, target = (x - self.mean) / self.std, (target - self.mean) / self.std
        content, style = x.new_zeros(()), x.new_zeros(())
        for layer in self.stages:
            x = layer(x)
            with torch.no_grad():
                target = layer(target)
            content = content + F.l1_loss(x, target)
            style = style + F.l1_loss(self.gram(x), self.gram(target))
        return content, style


class SLBRObjective(nn.Module):
    def __init__(self):
        super().__init__()
        self.vgg = VGGObjective()

    def forward(self, outputs, target, mask):
        # Autocast disabled around BCE probability inputs and perceptual losses.
        with torch.autocast(device_type=target.device.type, enabled=False):
            ims = [im.float() for im in outputs[0]]
            if len(ims) != 2 or len(outputs[1]) != 7:
                raise ValueError("Full refinement + three SMR levels required")
            target, mask = target.float(), mask.float()
            coarse = relative_l1(ims[-1], target, mask)
            refine = relative_l1(ims[0], target, mask)
            composites = [im * mask + target * (1 - mask) for im in ims]
            coarse = coarse + 1.5 * sum(F.l1_loss(im, target) for im in composites)
            content, style = target.new_zeros(()), target.new_zeros(())
            for image in composites:
                c, s = self.vgg(image, target)
                content, style = content + c, style + s
            maps = [F.interpolate(m.float(), size=mask.shape[-2:], mode="bilinear",
                                  align_corners=False).clamp(0, 1) for m in outputs[1]]
            mask_loss = F.binary_cross_entropy(maps[0], mask)
            primary, calibrated = maps[1::2][::-1], maps[2::2][::-1]
            for i, (p, c) in enumerate(zip(primary, calibrated)):
                intersection = (c * mask).flatten(1).sum(1)
                union = (c + mask - c * mask).flatten(1).sum(1)
                iou = (1 - intersection / union.clamp_min(1e-6)).mean()
                mask_loss = mask_loss + .5**i * (
                    .01 * F.binary_cross_entropy(p, mask)
                    + F.binary_cross_entropy(c, mask) + .25 * iou)
            total = 2 * (coarse + refine) + mask_loss + .25 * content + .25 * style
            return {"total": total, "coarse": coarse, "refine": refine,
                    "mask": mask_loss, "content": content, "style": style}
