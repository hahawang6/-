"""Bounded forward/loss diagnosis: same real sample, FP32 versus FP16 AMP.

No optimizer, backward, checkpoint export or training configuration changes.
"""
import argparse
import gc
import json
import traceback
from pathlib import Path
import torch
from .data import LogoDataset
from .losses import SLBRObjective
from .model import build_model, load_base_weights


def describe(t):
    t = t.detach()
    finite = torch.isfinite(t)
    valid = t[finite]
    return {"shape": list(t.shape), "dtype": str(t.dtype),
            "nan_count": torch.isnan(t).sum().item(),
            "inf_count": torch.isinf(t).sum().item(),
            "finite_min": valid.min().item() if valid.numel() else None,
            "finite_max": valid.max().item() if valid.numel() else None}


def tensors(value, path="output"):
    if torch.is_tensor(value):
        yield path, value
    elif isinstance(value, (tuple, list)):
        for i, item in enumerate(value):
            yield from tensors(item, f"{path}[{i}]")
    elif isinstance(value, dict):
        for key, item in value.items():
            yield from tensors(item, f"{path}.{key}")


def record_failure(report, name):
    def hook(module, inputs, outputs):
        for path, tensor in tensors(outputs):
            if tensor.is_floating_point() and not torch.isfinite(tensor).all():
                report["first_nonfinite"] = {"module": name,
                                              "class": type(module).__name__,
                                              "output": path,
                                              "stats": describe(tensor),
                                              "inputs": {p: describe(t) for p, t in tensors(inputs)
                                                         if t.is_floating_point()}}
                if isinstance(outputs, dict):
                    report["first_nonfinite"]["all_output_stats"] = {
                        p: describe(t) for p, t in tensors(outputs) if t.is_floating_point()}
                raise FloatingPointError(f"First observed nonfinite tensor: {name} ({path})")
    return hook


def run(args):
    torch.set_num_threads(4)
    report = {"scope": "Forward/loss diagnosis only. No model simplification or formal training.",
              "torch": torch.__version__, "device": args.device, "size": args.size,
              "checks": {}}
    destination = Path(args.output)
    destination.parent.mkdir(parents=True, exist_ok=True)
    try:
        device = torch.device(args.device)
        if device.type == "cuda":
            report["gpu"] = torch.cuda.get_device_name(device)
        dataset = LogoDataset(args.data_root, args.manifest, args.size, training=True)
        sample = dataset[0]
        report["source_id"] = sample["source_id"]
        inputs = {key: sample[key].unsqueeze(0) for key in ("image", "target", "mask")}
        report["input_stats"] = {key: describe(t) for key, t in inputs.items()}
        if not all(torch.isfinite(t).all() for t in inputs.values()):
            raise FloatingPointError("Dataset produced nonfinite input/target/mask")
        # FP32 first isolates whether AMP is necessary for reproducing this failure.
        for mode in ("fp32", "amp_fp16"):
            item = report["checks"][mode] = {}
            model = objective = outputs = losses = None
            hooks = []
            try:
                torch.manual_seed(20261021)
                model = build_model().to(device).train()
                item["weights"] = load_base_weights(model, args.base_weights)
                objective = SLBRObjective().to(device).eval()
                for prefix, network in (("model", model), ("objective", objective)):
                    bad = [name for name, tensor in network.state_dict().items()
                           if tensor.is_floating_point() and not torch.isfinite(tensor).all()]
                    if bad:
                        item["bad_weight_or_buffer_keys"] = {prefix: bad}
                        raise FloatingPointError("Nonfinite parameter or buffer before forward")
                    for name, module in network.named_modules():
                        hooks.append(module.register_forward_hook(record_failure(item, f"{prefix}.{name}")))
                x, y, mask = (inputs[k].to(device) for k in ("image", "target", "mask"))
                with torch.no_grad():
                    item["phase"] = "model_forward"
                    with torch.autocast(device.type, dtype=torch.float16, enabled=mode == "amp_fp16"):
                        outputs = model(x)
                    item["model_output_stats"] = {p: describe(t) for p, t in tensors(outputs)}
                    item["phase"] = "objective"
                    losses = objective(outputs, y, mask)
                    item["loss_stats"] = {name: describe(t) for name, t in losses.items()}
                    if not all(torch.isfinite(t).all() for t in losses.values()):
                        raise FloatingPointError("Nonfinite loss component")
                item["status"] = "forward_and_loss_finite"
            except Exception as exc:
                item["status"] = "failed"
                item["error"] = f"{type(exc).__name__}: {exc}"
                item["traceback"] = traceback.format_exc()
            finally:
                for hook in hooks:
                    hook.remove()
                del model, objective, outputs, losses
                gc.collect()
                if device.type == "cuda":
                    torch.cuda.empty_cache()
            print(mode, item["status"], item.get("error", ""), flush=True)
    except Exception as exc:
        report["setup_error"] = f"{type(exc).__name__}: {exc}"
        report["setup_traceback"] = traceback.format_exc()
    finally:
        destination.write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
        print("Diagnostic report:", destination.resolve(), flush=True)
    return report


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--device", default="cuda")
    p.add_argument("--size", type=int, default=256)
    p.add_argument("--data-root", default="data/raw/LOGO-Multi")
    p.add_argument("--manifest", default="data/splits/logo_multi_v1/train.csv")
    p.add_argument("--base-weights", default="weights/slbr-clwd-official.pth.tar")
    p.add_argument("--output", default="runs/numerics-diagnostic.json")
    run(p.parse_args())
