"""Single-process HTTP adapter around the uploaded, unchanged Predictor architecture.

Run: python -m wmr.web --weights path/to/best-weights.pt --device auto
"""
import argparse
import asyncio
from concurrent.futures import ThreadPoolExecutor
from contextlib import asynccontextmanager
from dataclasses import dataclass
import logging
import os
from pathlib import Path
import secrets
import shutil
import tempfile
import time
import warnings

import torch
from PIL import Image, ImageOps, UnidentifiedImageError
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from .infer import Predictor

LOG = logging.getLogger("wmr.web")
MAX_BYTES = 12 * 1024 * 1024
MAX_PIXELS = 4_000_000
MAX_DIMENSION = 8192
QUEUE_SIZE = 4
MAX_JOBS = 12
TTL_SECONDS = 15 * 60


@dataclass
class Job:
    id: str
    folder: Path
    width: int
    height: int
    created: float
    status: str = "queued"
    finished: float = 0.0
    expires: float = 0.0
    stats: dict | None = None
    error: str | None = None


def canonicalize(source: Path, target: Path):
    """Validate first; apply EXIF orientation, but never stretch/crop input here."""
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("error", Image.DecompressionBombWarning)
            with Image.open(source) as im:
                if im.format not in {"PNG", "JPEG", "WEBP"}:
                    raise ValueError("请选择 PNG、JPEG 或 WebP 图片。")
                if getattr(im, "n_frames", 1) != 1:
                    raise ValueError("暂不支持动画图片，请先导出为单张图片。")
                if im.width * im.height > MAX_PIXELS or max(im.size) > MAX_DIMENSION:
                    raise ValueError("图片不能超过 400 万像素，最长边不能超过 8192 像素。")
                im.load()
                # Preserve the existing Predictor's explicit alpha restriction.
                rgba = im.convert("RGBA") if "transparency" in im.info else im
                if "A" in rgba.getbands() and rgba.getchannel("A").getextrema() != (255, 255):
                    raise ValueError("暂不处理透明像素，请先将图片合成到不透明背景。")
                rgb = ImageOps.exif_transpose(im).convert("RGB")
                size = rgb.size
                rgb.save(target, "PNG")
                return size
    except (Image.DecompressionBombError, Image.DecompressionBombWarning):
        raise ValueError("图片尺寸过大，请缩小后重试。") from None
    except (UnidentifiedImageError, OSError):
        raise ValueError("图片无法读取，请确认文件完整后重试。") from None


def create_app(weights, device="auto", frontend=None, cpu_threads=4):
    root = Path(__file__).resolve().parents[1]
    frontend = Path(frontend or root / "frontend").resolve()
    weights = Path(weights).resolve()
    access_token = os.environ.get("WMR_ACCESS_TOKEN", "")
    jobs: dict[str, Job] = {}
    queue = asyncio.Queue(maxsize=QUEUE_SIZE)
    upload_lock = asyncio.Lock()

    @asynccontextmanager
    async def lifespan(app):
        if not weights.is_file():
            raise RuntimeError(f"Model weights not found: {weights}")
        if not (frontend / "index.html").is_file():
            raise RuntimeError("Frontend files not found")
        if cpu_threads < 1:
            raise ValueError("cpu_threads must be positive")
        torch.set_num_threads(cpu_threads)
        selected = "cuda" if device == "auto" and torch.cuda.is_available() else ("cpu" if device == "auto" else device)
        if selected.startswith("cuda") and not torch.cuda.is_available():
            raise RuntimeError("CUDA requested but unavailable. Use --device cpu or install the matching CUDA PyTorch.")
        # One constructor / one strict checkpoint load for the lifetime of this process.
        predictor = Predictor(weights, device=selected, size=256)
        app.state.predictor = predictor
        app.state.load_count = 1
        executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="wmr-inference")
        temp = tempfile.TemporaryDirectory(prefix="wa-yixia-")
        app.state.work_root = Path(temp.name)
        app.state.device = str(predictor.device)
        app.state.ready = True

        async def consumer():
            while True:
                job_id = await queue.get()
                job = jobs.get(job_id)
                try:
                    if job is None:
                        continue
                    job.status = "processing"
                    start = time.perf_counter()
                    def infer():
                        result, stats = predictor.process(job.folder / "original.png")
                        try:
                            result.save(job.folder / "result.png", "PNG")
                        finally:
                            result.close()
                        stats["processing_ms"] = (time.perf_counter() - start) * 1000
                        return stats
                    job.stats = await asyncio.get_running_loop().run_in_executor(executor, infer)
                    job.status = "succeeded"
                except asyncio.CancelledError:
                    raise
                except Exception:
                    LOG.exception("Inference failed for job %s", job_id)
                    if job is not None:
                        job.status = "failed"
                        job.error = "这次处理没有完成，请换张图片或稍后重试。"
                        for name in ("original.png", "result.png"):
                            (job.folder / name).unlink(missing_ok=True)
                    if predictor.device.type == "cuda":
                        torch.cuda.empty_cache()
                finally:
                    if job is not None:
                        job.finished = time.monotonic()
                        job.expires = job.finished + TTL_SECONDS
                    queue.task_done()

        async def cleaner():
            while True:
                await asyncio.sleep(30)
                cleanup()

        consumer_task = asyncio.create_task(consumer())
        cleaner_task = asyncio.create_task(cleaner())
        try:
            yield
        finally:
            app.state.ready = False
            consumer_task.cancel()
            cleaner_task.cancel()
            await asyncio.gather(consumer_task, cleaner_task, return_exceptions=True)
            # Wait for an in-flight executor call before deleting its files.
            executor.shutdown(wait=True, cancel_futures=True)
            jobs.clear()
            temp.cleanup()
            app.state.predictor = None

    app = FastAPI(title="蛙一下 · 图片去水印", lifespan=lifespan, docs_url=None, redoc_url=None, openapi_url=None)
    app.state.ready = False

    def cleanup():
        now = time.monotonic()
        for job_id, job in list(jobs.items()):
            if job.status in {"succeeded", "failed"} and job.expires <= now:
                shutil.rmtree(job.folder, ignore_errors=True)
                jobs.pop(job_id, None)

    def authorize(request):
        given = request.headers.get("X-Access-Token", "")
        if access_token and not secrets.compare_digest(given.encode(), access_token.encode()):
            raise HTTPException(401, "通行码不正确，请重新输入。")

    def get_job(job_id):
        job = jobs.get(job_id)
        if job is None or (job.finished and job.expires <= time.monotonic()):
            cleanup()
            raise HTTPException(404, "这份结果已过期或服务已重启，请重新上传。")
        if job.finished:
            job.expires = time.monotonic() + TTL_SECONDS
        return job

    def job_payload(job):
        position = None
        if job.status == "queued":
            waiting = [j.id for j in jobs.values() if j.status == "queued"]
            position = waiting.index(job.id) + 1 if job.id in waiting else 1
        return {"id": job.id, "status": job.status, "queue_position": position,
                "width": job.width, "height": job.height, "stats": job.stats, "error": job.error,
                "original_url": f"/api/jobs/{job.id}/original",
                "result_url": f"/api/jobs/{job.id}/result",
                "download_url": f"/api/jobs/{job.id}/download"}

    @app.middleware("http")
    async def headers(request, call_next):
        response = await call_next(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Referrer-Policy"] = "same-origin"
        if request.url.path.startswith("/api/"):
            response.headers["Cache-Control"] = "no-store"
        return response

    @app.get("/api/health")
    async def health():
        return {"ready": app.state.ready, "device": getattr(app.state, "device", None),
                "model": "SLBR + Fourier", "model_input": [256, 256],
                "auth_required": bool(access_token), "max_bytes": MAX_BYTES,
                "max_pixels": MAX_PIXELS, "retention_minutes": TTL_SECONDS // 60,
                "queue_capacity": QUEUE_SIZE,
                "busy": any(j.status == "processing" for j in jobs.values())}

    @app.post("/api/jobs", status_code=202)
    async def submit(request: Request):
        authorize(request)
        if not app.state.ready:
            raise HTTPException(503, "处理服务尚未准备好，请稍后重试。")
        if upload_lock.locked():
            raise HTTPException(429, "正在接收另一张图片，请稍后再试。")
        async with upload_lock:
            cleanup()
            if queue.full() or len(jobs) >= MAX_JOBS:
                raise HTTPException(429, "蛙正在忙，队列已满，请稍后再试。")
            length = request.headers.get("content-length")
            if length:
                try:
                    declared = int(length)
                except ValueError:
                    raise HTTPException(400, "无效的文件大小。") from None
                if declared > MAX_BYTES:
                    raise HTTPException(413, "图片文件不能超过 12 MB。")
            job_id = secrets.token_urlsafe(24)
            folder = app.state.work_root / job_id
            folder.mkdir()
            raw = folder / "upload.bin"
            accepted = False
            try:
                received = 0
                with raw.open("wb") as out:
                    async for chunk in request.stream():
                        received += len(chunk)
                        if received > MAX_BYTES:
                            raise HTTPException(413, "图片文件不能超过 12 MB。")
                        out.write(chunk)
                if not received:
                    raise HTTPException(400, "请选择一张图片。")
                try:
                    width, height = await asyncio.to_thread(canonicalize, raw, folder / "original.png")
                except ValueError as exc:
                    raise HTTPException(422, str(exc)) from None
                raw.unlink(missing_ok=True)
                job = Job(job_id, folder, width, height, time.monotonic())
                jobs[job_id] = job
                try:
                    queue.put_nowait(job_id)
                except asyncio.QueueFull:
                    jobs.pop(job_id, None)
                    raise HTTPException(429, "队列已满，请稍后重试。") from None
                accepted = True
                return job_payload(job)
            finally:
                if not accepted:
                    shutil.rmtree(folder, ignore_errors=True)

    @app.get("/api/jobs/{job_id}")
    async def status(job_id: str, request: Request):
        authorize(request)
        return job_payload(get_job(job_id))

    @app.get("/api/jobs/{job_id}/{kind}")
    async def image(job_id: str, kind: str, request: Request):
        authorize(request)
        job = get_job(job_id)
        if kind not in {"original", "result", "download"}:
            raise HTTPException(404, "找不到这个文件。")
        if job.status == "failed":
            raise HTTPException(410, job.error)
        if kind != "original" and job.status != "succeeded":
            raise HTTPException(409, "图片还在处理中，请稍等。")
        path = job.folder / ("original.png" if kind == "original" else "result.png")
        if not path.is_file():
            raise HTTPException(404, "这份图片已清理，请重新上传。")
        return FileResponse(path, media_type="image/png", filename="wa-yixia-clean.png" if kind == "download" else None)

    @app.delete("/api/jobs/{job_id}", status_code=204)
    async def delete(job_id: str, request: Request):
        authorize(request)
        job = get_job(job_id)
        if job.status in {"queued", "processing"}:
            raise HTTPException(409, "任务正在处理，完成后可以清除。")
        shutil.rmtree(job.folder, ignore_errors=True)
        jobs.pop(job_id, None)
        return None

    # Expose only frontend assets. Weights/source/temp directories are never static.
    app.mount("/", StaticFiles(directory=frontend, html=True), name="frontend")
    return app


def main():
    p = argparse.ArgumentParser(description="蛙一下 · 去水印本地与服务器应用")
    p.add_argument("--weights", required=True)
    p.add_argument("--device", default="auto", choices=["auto", "cpu", "cuda"])
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=8080)
    p.add_argument("--cpu-threads", type=int, default=4)
    args = p.parse_args()
    import uvicorn
    app = create_app(args.weights, args.device, cpu_threads=args.cpu_threads)
    # Deliberately no reload, multi-worker, model download or training at launch.
    uvicorn.run(app, host=args.host, port=args.port, workers=1)


if __name__ == "__main__":
    main()
