"""Full fixed-reference SLBR plus one Fourier residual branch."""
