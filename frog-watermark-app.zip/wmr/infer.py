import argparse
import time
from pathlib import Path
import torch
from PIL import Image
from .checkpoint import load_export
from .data import read_rgb, to_tensor
from .metrics import final_image
from .model import build_model


class Predictor:
    """One model load per Predictor. Single-image, global square-resize inference."""
    def __init__(self, weights, device="cuda", size=256):
        if size < 64 or size % 16:
            raise ValueError("Size must be >=64 and divisible by 16")
        self.device, self.size = torch.device(device), size
        self.model = build_model().to(self.device)
        load_export(self.model, weights, self.device)
        self.model.eval()

    @torch.inference_mode()
    def process(self, path):
        original = read_rgb(path)
        small = original.resize((self.size, self.size), Image.Resampling.BILINEAR)
        x = to_tensor(small).unsqueeze(0).to(self.device)
        if self.device.type == "cuda":
            torch.cuda.synchronize(self.device)
        start = time.perf_counter()
        outputs = self.model(x)
        if self.device.type == "cuda":
            torch.cuda.synchronize(self.device)
        forward_ms = (time.perf_counter()-start)*1000
        # Upsample RGB and predicted mask separately, blend with original RGB
        # to retain native background where the model predicts no watermark.
        rgb = torch.nn.functional.interpolate(outputs[0][0], size=(original.height, original.width),
                                              mode="bilinear", align_corners=False)
        mask = torch.nn.functional.interpolate(outputs[1][0], size=(original.height, original.width),
                                               mode="bilinear", align_corners=False)
        native = to_tensor(original).unsqueeze(0).to(self.device)
        result = (rgb*mask + native*(1-mask)).clamp(0, 1)
        if not torch.isfinite(result).all():
            raise RuntimeError("Nonfinite inference output; no image was exported")
        array = result[0].permute(1, 2, 0).mul(255).round().byte().cpu().numpy()
        return Image.fromarray(array), {"model_forward_ms": forward_ms,
                                        "model_input": [self.size, self.size],
                                        "original_size": list(original.size)}


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--weights", required=True)
    p.add_argument("--input", required=True)
    p.add_argument("--output", required=True)
    p.add_argument("--device", default="cuda")
    args = p.parse_args()
    predictor = Predictor(args.weights, args.device)
    start = time.perf_counter()
    result, stats = predictor.process(args.input)
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    result.save(args.output)
    stats["decode_preprocess_forward_postprocess_save_ms"] = (time.perf_counter()-start)*1000
    print(stats)
