"""Single-model training. Formal configuration must be explicitly approved."""
import argparse
import json
import math
import random
import time
from pathlib import Path
import numpy as np
import torch
from torch.utils.data import DataLoader
from .checkpoint import (make_optimizers, restore_training, save_training, export_weights)
from .data import LogoDataset
from .losses import SLBRObjective
from .metrics import evaluate_loader
from .model import build_model, load_base_weights, PRECISION_POLICY


def main(args):
    config = json.loads(Path(args.config).read_text(encoding="utf-8"))
    if not config["approved_for_formal_training"]:
        raise ValueError("Draft configuration: agree initialization and physical batch before formal training")
    if config["initialization"] not in ("scratch", "official"):
        raise ValueError("Choose scratch or official explicitly")
    if config.get("precision_policy") != PRECISION_POLICY:
        raise ValueError("Formal config does not match the verified precision policy")
    random.seed(config["seed"])
    np.random.seed(config["seed"])
    torch.manual_seed(config["seed"])
    device = torch.device(args.device)
    if device.type != "cuda":
        raise ValueError("Formal training is configured for the user's CUDA GPU")
    torch.cuda.manual_seed_all(config["seed"])
    train = LogoDataset(args.data_root, args.train_manifest, config["size"], True, config["seed"])
    val = LogoDataset(args.data_root, args.val_manifest, config["size"], False, config["seed"])
    if {r["source_id"] for r in train.rows} & {r["source_id"] for r in val.rows}:
        raise ValueError("Train/validation source overlap")
    data = {"train_sha256": train.digest, "val_sha256": val.digest}
    if data != config["manifest_sha256"]:
        raise ValueError("Training/validation manifests differ from the approved split")
    model = build_model().to(device)
    if not args.resume and config["initialization"] == "official":
        if not args.base_weights:
            raise ValueError("Official initialization requires --base-weights")
        print(load_base_weights(model, args.base_weights))
    objective = SLBRObjective().to(device).eval()
    optimizers = make_optimizers(model, config["lr"])
    schedulers = {k: torch.optim.lr_scheduler.MultiStepLR(o, [65], gamma=.1)
                  for k, o in optimizers.items()}
    scaler = torch.amp.GradScaler("cuda", enabled=config["amp"], init_scale=config["initial_scale"])
    epoch0, step, best = 0, 0, float("-inf")
    if args.resume:
        epoch0, step, best = restore_training(args.resume, model, optimizers, schedulers,
                                              scaler, config, data)
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    if not args.resume and (output / "last.pt").exists():
        raise ValueError("Output has a checkpoint: use --resume or a fresh output directory")
    run_info = {"config": config, "data": data, "train_samples": len(train), "val_samples": len(val),
                "gpu": torch.cuda.get_device_name(device), "torch": torch.__version__,
                "parameters": sum(p.numel() for p in model.parameters()), "resume": args.resume}
    (output / "run-config.json").write_text(json.dumps(run_info, indent=2), encoding="utf-8")
    print(json.dumps(run_info, indent=2), flush=True)
    val_loader = DataLoader(val, batch_size=1, shuffle=False, num_workers=0)
    consecutive_skips = 0
    for epoch in range(epoch0, config["epochs"]):
        train.epoch = epoch
        # Epoch-dependent ordering restores without consuming prior loader RNG states.
        generator = torch.Generator().manual_seed(config["seed"] + epoch)
        loader = DataLoader(train, batch_size=config["micro_batch"], shuffle=True,
                            generator=generator, num_workers=0, pin_memory=True, drop_last=False)
        model.train()
        start = time.perf_counter()
        for o in optimizers.values():
            o.zero_grad(set_to_none=True)
        running, samples, skipped_updates = 0., 0, 0
        torch.cuda.reset_peak_memory_stats(device)
        accumulation = config["accumulation"]
        for i, batch in enumerate(loader):
            group_start = (i // accumulation) * accumulation
            # Weight micro-batch mean by actual samples, including final partial batch.
            group_samples = min(accumulation * config["micro_batch"],
                                len(train) - group_start * config["micro_batch"])
            x, y, m = (batch[k].to(device, non_blocking=True) for k in ("image", "target", "mask"))
            with torch.autocast("cuda", dtype=torch.float16, enabled=config["amp"]):
                outputs = model(x)
            losses = objective(outputs, y, m)
            if not torch.isfinite(losses["total"]):
                raise FloatingPointError(f"Nonfinite loss: epoch={epoch+1}, batch={i}")
            scaler.scale(losses["total"] * (len(x)/group_samples)).backward()
            running += losses["total"].item()*len(x)
            samples += len(x)
            if (i+1) % accumulation == 0 or i+1 == len(loader):
                for o in optimizers.values():
                    scaler.unscale_(o)
                # Keep all four optimizers in sync when AMP overflows.
                finite = all(torch.isfinite(p.grad).all().item() for p in model.parameters()
                             if p.grad is not None)
                if finite:
                    for o in optimizers.values():
                        scaler.step(o)
                    step += 1
                    consecutive_skips = 0
                elif not config["amp"]:
                    raise FloatingPointError("Nonfinite gradients in FP32 training")
                else:
                    skipped_updates += 1
                    consecutive_skips += 1
                    print(f"AMP overflow: skipping all four optimizer updates at scale={scaler.get_scale()}", flush=True)
                scaler.update()
                for o in optimizers.values():
                    o.zero_grad(set_to_none=True)
                if consecutive_skips >= 8:
                    raise FloatingPointError("8 consecutive AMP update overflows; stop and inspect, not successful training")
            if (i+1) % 50 == 0:
                print(f"epoch={epoch+1} batch={i+1}/{len(loader)} loss={running/samples:.5f}", flush=True)
        metrics = evaluate_loader(model, val_loader, device)
        improved = metrics["psnr"] > best
        if improved:
            best = metrics["psnr"]
        for scheduler in schedulers.values():
            scheduler.step()
        record = {"epoch": epoch+1, "loss": running/samples, "validation": metrics,
                  "seconds": time.perf_counter()-start, "optimizer_steps": step,
                  "amp_skipped_updates": skipped_updates, "amp_scale": scaler.get_scale(),
                  "peak_gpu_mib": torch.cuda.max_memory_allocated()/1024**2}
        with (output / "history.jsonl").open("a", encoding="utf-8") as f:
            f.write(json.dumps(record)+"\n")
        print(json.dumps(record), flush=True)
        if improved:
            export_weights(model, output/"best-weights.pt")
        save_training(output/"last.pt", model, optimizers, schedulers, scaler,
                      epoch+1, step, best, config, data)
    print("Training completed. Best validation PSNR:", best)


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--config", default="configs/train-formal.json")
    p.add_argument("--data-root", default="data/raw/LOGO-Multi")
    p.add_argument("--train-manifest", default="data/splits/logo_multi_v1/train.csv")
    p.add_argument("--val-manifest", default="data/splits/logo_multi_v1/val.csv")
    p.add_argument("--output", default="runs/slbr-fourier-v1")
    p.add_argument("--device", default="cuda")
    p.add_argument("--resume")
    p.add_argument("--base-weights")
    main(p.parse_args())
