import torch
from torch import nn


class FourierResidual(nn.Module):
    """Learned low-resolution spectral residual; 12,353 parameters.

    FFT in FP32. Explicit Hermitian projection on rFFT boundary columns
    prevents learning unrepresentable imaginary components at those columns.
    """
    def __init__(self):
        super().__init__()
        self.reduce = nn.Conv2d(128, 32, 1, bias=False)
        self.spectral = nn.Sequential(nn.Conv2d(64, 64, 1), nn.GELU())
        self.expand = nn.Conv2d(32, 128, 1, bias=False)
        self.gamma = nn.Parameter(torch.tensor(1e-3))

    def forward(self, feature):
        with torch.autocast(device_type=feature.device.type, enabled=False):
            x = self.reduce(feature.float())
            h, w = x.shape[-2:]
            z = torch.fft.rfft2(x, norm="ortho")
            learned = self.spectral(torch.cat((z.real, z.imag), dim=1))
            real, imag = learned.chunk(2, dim=1)
            z = torch.complex(real, imag)
            mirror = (-torch.arange(h, device=z.device)) % h
            symmetric = 0.5 * (z + z.index_select(-2, mirror).conj())
            columns = torch.arange(z.shape[-1], device=z.device)
            boundary = (columns == 0) | ((columns == w // 2) & (w % 2 == 0))
            z = torch.where(boundary.view(1, 1, 1, -1), symmetric, z)
            residual = self.expand(torch.fft.irfft2(z, s=(h, w), norm="ortho"))
            result = feature.float() + self.gamma * residual
        return result.to(feature.dtype)
