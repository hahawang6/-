(() => {
'use strict';
const $ = s => document.querySelector(s);
const items = [
 ['happy','乐',0,'开心营业','快乐没有理由，蛙也没有。','#eaf3dd','今日推荐'],
 ['grumpy','不乐',1,'暂不营业','今天不营业，明天再说。','#ebe9e2','允许摆烂'],
 ['confused','疑惑',2,'迷惑日常','脑袋空空，问题很多。','#fff0bd','容蛙想想'],
 ['serious','严肃',3,'认真一下','蛙很严肃，但蛙没有意见。','#e9ecdf','认真营业'],
 ['sleepy','睡觉觉',4,'暂不营业','先充电，再当厉害的人。','#f5e0e6','请轻一点'],
 ['hero','我来拯救',5,'认真一下','大事不会，小事蛙来。','#fff0c6','蛙力满格'],
 ['delighted','欣喜',6,'开心营业','今天也值得被摸摸脑袋。','#eaf0df','给你一朵花'],
 ['breakfast','早膳',7,'开心营业','吃饱了，才有力气蛙一下。','#f5e7d6','饭要好好吃'],
 ['melancholy','忧郁',8,'暂不营业','有一点点灰，也没关系。','#e8eae5','接住心情'],
 ['okay','OK',9,'开心营业','问题不大，蛙给你比个 OK。','#f5e2df','放心，收到'],
 ['uh-huh','嗯嗯',10,'迷惑日常','嗯嗯，蛙在听，蛙都懂。','#f5edcf','听你说'],
 ['cute','可爱',11,'开心营业','可爱这件事，蛙自有分寸。','#edf0dd','悄悄卖萌'],
 ['received','收到',12,'认真一下','收到！正在努力理解人类。','#e3ece1','已读，已蛙'],
 ['slacking','摸鱼',13,'暂不营业','暂时下线，去池塘待一会儿。','#e7eede','松一口气'],
 ['friends','蛙友集合',14,'开心营业','人类的事，蛙们开会再说。','#f5e5d9','凑个热闹'],
 ['thinking','思考中',15,'迷惑日常','看似深思熟虑，其实没有加载。','#e9e7ed','容蛙想想']
].map(([id,name,art,category,caption,color,tag])=>({id,name,art,category,caption,color,tag}));
const moods = [
 ['happy','乐','把这点开心存起来，也可以分一点给喜欢的人。'],
 ['grumpy','不乐','不必强行开心。给自己一点安静的空间吧。'],
 ['confused','疑惑','先把最困惑的一件事写下来，其他的慢慢想。'],
 ['serious','严肃','只做眼前的一小件事，也是一种很厉害的认真。'],
 ['sleepy','困了','放下肩膀，闭眼歇一会儿。休息也是正经事。'],
 ['hero','我来拯救','先帮自己倒杯水。拯救世界，从照顾自己开始。']
].map(([id,label,tip])=>({id,label,tip}));
const tasks = ['肩膀放下来，慢慢呼气三次。','喝口水，给脑袋加一点池塘。','看看窗外最远的地方，让眼睛散个步。','站起来，假装自己是很忙的蛙。','把眉头松开，今天不用那么用力。','伸伸手指，再给自己一个大大的懒腰。','找一件绿色的东西，和它对视三秒。','给自己说一句：已经很不错啦。','把手机轻轻放下，听一听身边的声音。','活动一下脚踝，向地板发送一个问候。','揉揉双手，再轻轻拍拍自己的肩膀。','把桌上一件小东西放回原位，就一件。'];
const key='wa-yixia:emotion-store:v1', ids=new Set(items.map(e=>e.id)), find=id=>items.find(e=>e.id===id);
let state={mood:'happy',favorites:[]}, filter='全部', query='', opened=null, opener=null, storageOK=true, toastTimer, lastTask=-1, taskCount=0;
try { const saved=JSON.parse(localStorage.getItem(key)||'null'); if(saved){if(moods.some(m=>m.id===saved.mood))state.mood=saved.mood;if(Array.isArray(saved.favorites))state.favorites=[...new Set(saved.favorites.filter(id=>ids.has(id)))];} } catch{}
function art(el,index){
 const source=window.FROG_ASSETS.characters[index];if(!source)return;
 el.style.backgroundImage=`url("${source.src}")`;
 if(source.crop){const[x,y,w,h]=source.crop,[sw,sh]=source.sourceSize;el.style.backgroundSize=`${sw/w*100}% ${sh/h*100}%`;el.style.backgroundPosition=`${x/(sw-w)*100}% ${y/(sh-h)*100}%`;}
 else{el.style.backgroundSize='contain';el.style.backgroundPosition='center';}
}
function notify(text){const el=$('#toast');clearTimeout(toastTimer);el.textContent=text;el.classList.add('show');toastTimer=setTimeout(()=>el.classList.remove('show'),2400);}
function save(){try{localStorage.setItem(key,JSON.stringify(state));storageOK=true;}catch{storageOK=false;notify('浏览器暂时不能保存，当前选择仍可继续使用。');}}
function animate(el,cls){el.classList.remove(cls);void el.offsetWidth;el.classList.add(cls);el.addEventListener('animationend',()=>el.classList.remove(cls),{once:true});}
function make(tag,cls,text){const el=document.createElement(tag);if(cls)el.className=cls;if(text!==undefined)el.textContent=text;return el;}
document.querySelectorAll('[data-frog]').forEach(el=>art(el,Number(el.dataset.frog)));
function renderMood(bounce=false){
 const mood=moods.find(m=>m.id===state.mood),item=find(mood.id);
 art($('#mood-art'),item.art);$('#mood-art').setAttribute('aria-label',`${mood.label}的蛙`);
 $('#mood-caption').textContent=item.caption;$('#mood-tip').textContent=mood.tip;$('#mood-stamp').textContent=mood.label;
 $('#mood-stamp').classList.toggle('long',mood.label.length>2);
 $('#mood-display').style.backgroundColor=mood.id==='sleepy'?'#f8dfe5':mood.id==='grumpy'?'#e8eadc':'#ffe78a';
 $('#mood-options').querySelectorAll('button').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.mood===state.mood)));
 if(bounce)animate($('#mood-display'),'changed');
}
moods.forEach(m=>{
 const b=make('button','mood-option');b.type='button';b.dataset.mood=m.id;b.setAttribute('aria-pressed','false');b.setAttribute('aria-label',`今日心情：${m.label}`);
 const a=make('span','frog-art');a.setAttribute('aria-hidden','true');art(a,find(m.id).art);b.append(a,make('span','option-name',m.label));
 b.addEventListener('click',()=>{state.mood=m.id;save();renderMood(true);$('#saved-note').textContent=storageOK?`✓ 今日${m.label}蛙，已经帮你记住啦。`:'本次心情已选好；当前浏览器暂时不能保存。';});$('#mood-options').append(b);
});renderMood();
['全部','开心营业','暂不营业','迷惑日常','认真一下'].forEach(category=>{
 const b=make('button','filter-chip',category);b.type='button';b.setAttribute('aria-pressed',String(category===filter));
 b.addEventListener('click',()=>{filter=category;$('#filters').querySelectorAll('button').forEach(el=>el.setAttribute('aria-pressed',String(el===b)));renderShelf();});$('#filters').append(b);
});
function favoriteLabel(b,item){const selected=state.favorites.includes(item.id);b.textContent=selected?'♥':'♡';b.setAttribute('aria-pressed',String(selected));b.setAttribute('aria-label',`${selected?'取消收藏':'收藏'}${item.name}`);b.title=b.getAttribute('aria-label');}
function card(item){
 const el=make('article','expression-card');el.dataset.expression=item.id;el.style.setProperty('--card-color',item.color);
 const open=make('button','expression-open');open.type='button';open.setAttribute('aria-label',`放大查看：${item.name}`);
 const wrap=make('div','card-art-wrap'),a=make('span','frog-art');a.setAttribute('aria-hidden','true');art(a,item.art);wrap.append(a);
 const row=make('div','card-name-row');row.append(make('span','card-name',item.name),make('span','card-number',`NO. ${String(items.indexOf(item)+1).padStart(2,'0')}`));
 open.append(wrap,row,make('p','card-caption',item.caption));open.addEventListener('click',()=>openDialog(item.id,open));
 const fav=make('button','favorite-button');fav.type='button';fav.dataset.favorite=item.id;favoriteLabel(fav,item);fav.addEventListener('click',()=>toggleFavorite(item.id,fav));
 el.append(open,make('span','card-tag',item.tag),fav);return el;
}
function renderShelf(){const list=items.filter(e=>(filter==='全部'||e.category===filter)&&e.name.toLowerCase().includes(query.toLowerCase()));$('#expression-grid').replaceChildren(...list.map(card));$('#result-count').textContent=query||filter!=='全部'?`找到 ${list.length} 只懂你的蛙`:`${items.length} 只蛙，在此营业`;$('#search-empty').hidden=!!list.length;}
function renderFavorites(){const list=state.favorites.map(find).filter(Boolean);$('#favorites-grid').replaceChildren(...list.map(card));$('#favorites-empty').hidden=!!list.length;$('#favorites-grid').hidden=!list.length;$('#collection-total').textContent=`${list.length} 只蛙入住`;$('#nav-count').textContent=list.length;$('#nav-count').hidden=!list.length;}
function dialogFavorite(){const selected=state.favorites.includes(opened);$('#dialog-favorite').textContent=selected?'♥ 已收藏 · 点此取消':'♡ 把这只蛙带回家';$('#dialog-favorite').setAttribute('aria-pressed',String(selected));}
function toggleFavorite(id,b){
 const selected=state.favorites.includes(id),inCollection=b?.closest('#favorites-grid');
 const index=inCollection?[...$('#favorites-grid').querySelectorAll('.favorite-button')].indexOf(b):-1;
 state.favorites=selected?state.favorites.filter(i=>i!==id):[...state.favorites,id];save();
 document.querySelectorAll('[data-favorite]').forEach(el=>{if(el.dataset.favorite===id)favoriteLabel(el,find(id));});
 if(b)animate(b,'favorite-pop');renderFavorites();if(opened===id)dialogFavorite();
 if(inCollection){const remaining=$('#favorites-grid').querySelectorAll('.favorite-button');if(remaining.length)remaining[Math.min(index,remaining.length-1)].focus();else $('#favorites-empty a').focus({preventScroll:true});}
 if(storageOK)notify(selected?'这只蛙回货架啦，想它时再来。':'♡ 收到！这只蛙已住进收藏。');
}
$('#search').addEventListener('input',e=>{query=e.target.value.trim();renderShelf();});
$('#reset-search').addEventListener('click',()=>{query='';filter='全部';$('#search').value='';$('#filters').querySelectorAll('button').forEach(b=>b.setAttribute('aria-pressed',String(b.textContent==='全部')));renderShelf();$('#search').focus();});renderShelf();renderFavorites();
const dialog=$('#expression-dialog');
function openDialog(id,button){const item=find(id);opened=id;opener=button;$('#dialog-title').textContent=item.name;$('#dialog-description').textContent=item.caption;art($('#dialog-art'),item.art);$('#dialog-art').setAttribute('aria-label',item.name);$('.dialog-art-wrap').style.background=item.color;dialogFavorite();dialog.showModal();document.body.classList.add('modal-open');dialog.scrollTop=0;$('#dialog-close').focus({preventScroll:true});}
$('#dialog-close').addEventListener('click',()=>dialog.close());
dialog.addEventListener('click',e=>{if(e.target===dialog){const r=dialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)dialog.close();}});
dialog.addEventListener('close',()=>{document.body.classList.remove('modal-open');opened=null;if(opener?.isConnected)opener.focus({preventScroll:true});});
$('#dialog-favorite').addEventListener('click',()=>{if(opened)toggleFavorite(opened,$('#dialog-favorite'));});
const poses=[9,12,3,11,0,14],sayings=['问题不大，先蛙一下。','收到，人类先休息。','蛙很严肃，蛙没有意见。','可爱一下，怎么了嘛。','允许开心，也允许发呆。','人类的事，开个蛙会。'];let hero=0,clicks=0,lastClick=0;
art($('#hero-frog .frog-art'),poses[0]);$('#hero-frog .frog-art').setAttribute('aria-label','比着 OK 手势的蛙');
$('#hero-frog').addEventListener('click',()=>{const now=Date.now();clicks=now-lastClick<1400?clicks+1:1;lastClick=now;hero=(hero+1)%poses.length;art($('#hero-frog .frog-art'),poses[hero]);$('#hero-frog .frog-art').setAttribute('aria-label','换了个表情的蛙');$('#hero-bubble').textContent=clicks>=5?'人类体验卡已暂停，恭喜蛙化！':sayings[hero];if(clicks===5)notify('✦ 彩蛋！今日蛙籍，正式生效。');animate($('#hero-frog'),'pop');});
$('#draw-task').addEventListener('click',()=>{
 const b=$('#draw-task');if(b.disabled)return;b.disabled=true;b.textContent='正在补充蛙力…';const machine=$('#supply-machine'),paper=$('#task-paper');paper.classList.remove('dispensed');machine.classList.add('drawing');
 setTimeout(()=>{let next=Math.floor(Math.random()*(tasks.length-1));if(next>=lastTask)next++;next%=tasks.length;lastTask=next;taskCount++;$('#task-text').textContent=tasks[next];$('#task-footer').replaceChildren(document.createTextNode(`第 ${String(taskCount).padStart(2,'0')} 份蛙力 · 请慢慢享用`),make('span','', '☺'));machine.classList.remove('drawing');animate(paper,'dispensed');b.disabled=false;b.innerHTML='再给我一点蛙力 <span aria-hidden="true">↓</span>';},matchMedia('(prefers-reduced-motion: reduce)').matches?40:550);
});
window.addEventListener('storage',event=>{if(event.key!==key)return;try{const value=JSON.parse(event.newValue);if(!value)return;if(moods.some(m=>m.id===value.mood))state.mood=value.mood;if(Array.isArray(value.favorites))state.favorites=[...new Set(value.favorites.filter(id=>ids.has(id)))];renderMood();renderShelf();renderFavorites();if(opened)dialogFavorite();}catch{}});
})();
