(() => {
'use strict';
const $=s=>document.querySelector(s);
let selected=null,previewURL=null,originalURL=null,resultURL=null,health=null,busy=false,job=null,pollTimer=null,pollFailures=0,selectionVersion=0;
const maxBytes=12*1024*1024,maxPixels=4000000;
try{$('#access-token').value=sessionStorage.getItem('wa-yixia:access')||'';}catch{}
const tokenHeaders=()=>$('#access-token').value?{'X-Access-Token':$('#access-token').value}:{};
function message(text){$('#workbench-message').textContent=text;}
function revoke(url){if(url)URL.revokeObjectURL(url);}
function setBusy(value){busy=value;$('#output-side').setAttribute('aria-busy',String(value));$('#choose-file').disabled=value;$('#image-file').disabled=value;$('#clear-image').disabled=value;$('.upload-side').classList.toggle('is-busy',value);updateButton();}
function updateButton(){const b=$('#process-image');b.disabled=!selected||!health?.ready||busy||(health?.auth_required&&!$('#access-token').value);b.innerHTML=busy?'蛙正在处理，请稍等…':'让蛙去水印 <span aria-hidden="true">↗</span>';}
async function request(url,options={}){
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),options.timeout||30000);
 try{
  const response=await fetch(url,{...options,headers:{...tokenHeaders(),...(options.headers||{})},signal:controller.signal,cache:'no-store'});
  if(!response.ok){let detail='处理服务暂时没有响应，请稍后重试。';try{const body=await response.json();if(typeof body.detail==='string')detail=body.detail;}catch{}const error=new Error(detail);error.status=response.status;throw error;}
  return response;
 }finally{clearTimeout(timer);}
}
function serviceNote(text,canRetry=false){const el=$('#service-note');el.replaceChildren(document.createTextNode(text));if(canRetry){const b=document.createElement('button');b.type='button';b.className='text-button';b.textContent='重新连接';b.addEventListener('click',checkHealth);el.append(b);}}
async function checkHealth(){
 const badge=$('#service-badge');badge.className='service-badge';badge.querySelector('span').textContent='正在查看小店状态…';
 try{
  const data=await(await request('/api/health',{timeout:6000})).json();
  if(typeof data.ready!=='boolean'||data.model!=='SLBR + Fourier')throw new Error('不是预期的处理服务');
  health=data;$('#access-field').hidden=!data.auth_required;
  if(data.ready){badge.classList.add('ready');badge.querySelector('span').textContent=data.device?.startsWith('cuda')?'显卡处理 · 已就绪':'处理服务 · 已就绪';serviceNote(data.auth_required?'输入通行码并选图，就可以开始啦。':'处理服务已就绪，选一张图片就可以开始啦。');}
  else{badge.classList.add('offline');badge.querySelector('span').textContent='处理服务正在准备';serviceNote('模型尚未就绪，请稍后重新连接。',true);}
 }catch{
  health=null;badge.classList.add('offline');badge.querySelector('span').textContent='尚未连接模型';serviceNote('当前只能浏览页面。请按随包说明启动完整应用后，再来处理图片。',true);
 }updateButton();
}
$('#access-token').addEventListener('input',()=>{try{sessionStorage.setItem('wa-yixia:access',$('#access-token').value);}catch{}updateButton();});
function clearResults(){clearTimeout(pollTimer);revoke(originalURL);revoke(resultURL);originalURL=resultURL=null;job=null;$('#result-view').hidden=true;$('#compare-tabs').hidden=true;$('#processing-state').hidden=true;$('#output-empty').hidden=false;$('#resume-job').hidden=true;for(const id of ['compare-original','compare-clean','pair-original','pair-clean'])$('#'+id).removeAttribute('src');$('#download-result').removeAttribute('href');}
function resetFile(){if(busy)return;selectionVersion++;selected=null;revoke(previewURL);previewURL=null;$('#image-file').value='';$('#upload-preview-image').removeAttribute('src');$('#upload-preview').hidden=true;clearResults();message('');updateButton();}
async function choose(file){
 if(busy||!file)return;const version=++selectionVersion;message('');
 if(file.size>maxBytes){message('图片文件不能超过 12 MB，请缩小后重试。');return;}
 if(!/\.(png|jpe?g|webp)$/i.test(file.name)&&!['image/png','image/jpeg','image/webp'].includes(file.type)){message('请选择 PNG、JPEG 或 WebP 图片。');return;}
 const url=URL.createObjectURL(file),image=new Image();
 try{
  image.src=url;await image.decode();
  if(image.naturalWidth*image.naturalHeight>maxPixels||Math.max(image.naturalWidth,image.naturalHeight)>8192){revoke(url);message('图片不能超过 400 万像素，最长边不能超过 8192 像素。');return;}
  // Decode is asynchronous; ignore a stale selection if another file was chosen meanwhile.
  if(busy||version!==selectionVersion){revoke(url);return;}
  revoke(previewURL);previewURL=url;selected=file;clearResults();
  $('#upload-preview-image').src=url;$('#upload-preview').hidden=false;$('#upload-filename').textContent=file.name;
  $('#upload-dimensions').textContent=`${image.naturalWidth} × ${image.naturalHeight} · ${(file.size/1024/1024).toFixed(2)} MB`;
  updateButton();
 }catch{revoke(url);message('这张图片无法打开，请换一个完整的图片文件。');}
}
$('#choose-file').addEventListener('click',()=>$('#image-file').click());$('#image-file').addEventListener('change',e=>choose(e.target.files[0]));$('#clear-image').addEventListener('click',resetFile);
const drop=$('#drop-zone');let dragDepth=0;
drop.addEventListener('dragenter',e=>{e.preventDefault();if(!busy){dragDepth++;drop.classList.add('drag-over');}});drop.addEventListener('dragover',e=>e.preventDefault());drop.addEventListener('dragleave',e=>{e.preventDefault();if(--dragDepth<=0){dragDepth=0;drop.classList.remove('drag-over');}});drop.addEventListener('drop',e=>{e.preventDefault();dragDepth=0;drop.classList.remove('drag-over');if(e.dataTransfer.files.length>1){message('一次放一张就好，蛙会认真处理。');return;}choose(e.dataTransfer.files[0]);});
function progress(title,detail,stage){$('#processing-title').textContent=title;$('#processing-detail').textContent=detail;['upload','process','result'].forEach((id,index)=>{$('#step-'+id).classList.toggle('active',index===stage);$('#step-'+id).classList.toggle('done',index<stage);});}
function processingPanel(){ $('#output-empty').hidden=true;$('#result-view').hidden=true;$('#compare-tabs').hidden=true;$('#processing-state').hidden=false;$('#resume-job').hidden=true;}
function paused(text){setBusy(false);$('#resume-job').hidden=false;progress('连接暂时中断，任务可能仍在处理。',text,1);}
async function showResult(data){
 const [before,after]=await Promise.all([request(data.original_url),request(data.result_url)]);
 const [a,b]=await Promise.all([before.blob(),after.blob()]);
 if(!a.type.startsWith('image/')||!b.type.startsWith('image/'))throw new Error('结果图片无法读取，请重试。');
 revoke(originalURL);revoke(resultURL);originalURL=URL.createObjectURL(a);resultURL=URL.createObjectURL(b);
 $('#compare-original').src=$('#pair-original').src=originalURL;$('#compare-clean').src=$('#pair-clean').src=resultURL;
 $('#compare-frame').style.aspectRatio=`${data.width} / ${data.height}`;$('#compare-range').value=50;updateSplit();
 $('#download-result').href=resultURL;$('#download-result').download='wa-yixia-clean.png';
 const seconds=(data.stats?.processing_ms||0)/1000;$('#result-stats').textContent=`${data.width} × ${data.height} · PNG${seconds?' · 本次处理 '+seconds.toFixed(2)+' 秒':''}`;
 $('#processing-state').hidden=true;$('#result-view').hidden=false;$('#compare-tabs').hidden=false;$('#output-empty').hidden=true;setBusy(false);message('处理完成。请检查水印残留和背景细节，再决定是否下载使用。');
}
async function poll(){
 if(!job)return;
 try{
  const data=await(await request(`/api/jobs/${encodeURIComponent(job.id)}`,{timeout:12000})).json();job=data;pollFailures=0;
  if(data.status==='succeeded'){await showResult(data);return;}
  if(data.status==='failed'){setBusy(false);progress('这次没能完成。',data.error||'请换张图片试试。',1);message(data.error||'处理失败，请重试。');return;}
  if(data.status==='queued')progress('图片已收到，正在排队。',`你是等待队列中的第 ${data.queue_position||1} 张，前面的图片处理完就轮到你。`,0);
  else if(data.status==='processing')progress('蛙正在认真处理。','这是实际模型推理，请稍等。你可以往下逛逛摸鱼补给。',1);
  else throw new Error('无法确认这个任务的状态。');
  pollTimer=setTimeout(poll,1000);
 }catch(error){
  pollFailures++;
  if(error.status===404){setBusy(false);progress('这份结果已经不在小店里了。','服务可能已重启，或结果已过期，请重新上传。',1);message('任务不存在或已过期，请重新处理图片。');return;}
  if(error.status===401){paused('请检查通行码，然后点击继续查看。');return;}
  if(pollFailures<3){progress('正在重新连接…','暂时没有收到任务状态，蛙会再试一下。',1);pollTimer=setTimeout(poll,2000);}
  else paused('恢复连接后，点击下方按钮查看同一个任务，无需重复提交。');
 }
}
$('#process-image').addEventListener('click',async()=>{
 if(!selected||busy||!health?.ready)return;clearResults();setBusy(true);message('');processingPanel();progress('蛙正在接收图片。','接收完成后，会按顺序交给模型处理。',0);
 try{
  job=await(await request('/api/jobs',{method:'POST',body:selected,headers:{'Content-Type':selected.type||'application/octet-stream'},timeout:60000})).json();
  pollFailures=0;await poll();
 }catch(error){setBusy(false);progress('图片还没有成功交给蛙。',error.name==='AbortError'?'上传等待时间过长，请检查连接。':error.message,0);message(error.name==='AbortError'?'连接超时，无法确认是否已收到图片。':error.message);}
});
$('#resume-job').addEventListener('click',()=>{if(!job||busy)return;setBusy(true);$('#resume-job').hidden=true;pollFailures=0;poll();});
function updateSplit(){const value=$('#compare-range').value;$('#compare-frame').style.setProperty('--split',`${value}%`);$('#compare-range').setAttribute('aria-valuetext',`处理后显示 ${value}%`);}
$('#compare-range').addEventListener('input',updateSplit);
function mode(pair){$('#pair-view').hidden=!pair;$('#compare-frame').hidden=pair;$('#mode-pair').setAttribute('aria-pressed',String(pair));$('#mode-slider').setAttribute('aria-pressed',String(!pair));}
$('#mode-pair').addEventListener('click',()=>mode(true));$('#mode-slider').addEventListener('click',()=>mode(false));
$('#delete-result').addEventListener('click',async()=>{
 if(!job||busy)return;const b=$('#delete-result');b.disabled=true;
 try{await request(`/api/jobs/${encodeURIComponent(job.id)}`,{method:'DELETE'});resetFile();message('本次上传和结果已从处理服务清除。');}
 catch(error){if(error.status===404){resetFile();message('这份结果已过期或已被清理。');}else message('暂时无法确认清理是否完成，临时文件仍按保留时间自动清理。');}
 finally{b.disabled=false;}
});
window.addEventListener('pagehide',()=>{clearTimeout(pollTimer);revoke(previewURL);revoke(originalURL);revoke(resultURL);});
checkHealth();
})();
