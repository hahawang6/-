/* 素材唯一入口。crop 为浏览器显示窗口 [x,y,width,height]，不修改原图像素。
 * 单图替换：修改 src 并删除 crop/sourceSize。未使用 AI 重绘素材。
 */
window.FROG_ASSETS = {
  provenance: '原版角色转载图，非作者透明源文件，网页使用授权未核实。',
  characters: {
    0: {src:'assets/originals/frog-11.jpg',sourceSize:[493,690],crop:[45,60,115,115]},
    1: {src:'assets/originals/frog-11.jpg',sourceSize:[493,690],crop:[180,175,115,115]},
    2: {src:'assets/originals/frog-11.jpg',sourceSize:[493,690],crop:[180,60,115,115]},
    3: {src:'assets/originals/frog-02.jpg'},
    4: {src:'assets/originals/frog-10.jpg',sourceSize:[496,690],crop:[173,68,128,128]},
    5: {src:'assets/originals/frog-11.jpg',sourceSize:[493,690],crop:[28,296,155,155]},
    6: {src:'assets/originals/frog-09.jpg'},
    7: {src:'assets/originals/frog-03.jpg'},
    8: {src:'assets/originals/frog-11.jpg',sourceSize:[493,690],crop:[33,175,120,120]},
    9: {src:'assets/originals/frog-04.jpg'},
    10: {src:'assets/originals/frog-05.jpg'},
    11: {src:'assets/originals/frog-06.jpg'},
    12: {src:'assets/originals/frog-01.jpg'},
    13: {src:'assets/originals/frog-12.jpg',sourceSize:[490,690],crop:[95,53,260,260]},
    14: {src:'assets/originals/frog-07.jpg'},
    15: {src:'assets/originals/frog-08.jpg'}
  }
};
