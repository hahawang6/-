# 蛙一下 · 图片去水印（模型接入版）

这是完整的 **蛙蛙主题前端 + Python 推理服务**，复用你上传的 SLBR + Fourier 网络及 `Predictor`。不是只有静态页面，也不会模拟去水印结果。无需重新训练。

## Windows：沿用你已有的训练环境

把此压缩包的内容解压到：

```text
D:\AIProjects\frog-watermark-app
```

该目录下面应直接看到 `wmr`、`frontend`、`requirements-web.txt`，不要再嵌套一层同名目录。

打开 Windows PowerShell，执行：

```powershell
Set-Location "D:\AIProjects\frog-watermark-app"

& "D:\AIProjects\watermark-removal\.venv\Scripts\python.exe" -m pip install -r requirements-web.txt

& "D:\AIProjects\watermark-removal\.venv\Scripts\python.exe" -m wmr.web `
    --weights "D:\AIProjects\watermark-removal\runs\slbr-fourier-v1\best-weights.pt" `
    --device cuda `
    --port 8080
```

看到 `Application startup complete` 后，打开 **http://127.0.0.1:8080**。

- 页面应显示“显卡处理 · 已就绪”；这是服务返回的真实 CUDA 状态。
- 安装依赖只需首次执行；以后直接执行启动命令即可。
- 也可在当前目录执行 `powershell -ExecutionPolicy Bypass -File .\start-local.ps1`。该参数仅作用于本次 PowerShell 进程，不修改系统策略。
- 停止：回到运行窗口按 Ctrl+C。关闭窗口也会停止服务。
- 端口冲突：改成 `--port 8081`，访问地址也改为 http://127.0.0.1:8081。
- 不要再使用 `python -m http.server` 启动这个应用；它只能提供静态页面，无法运行模型。
- 压缩包**不重复包含 82 MB 权重**。上面的命令直接读取你原项目中的现有文件，不复制、不修改它。

如果明确想使用 CPU，改为 `--device cpu`。不要为了安装网页依赖而覆盖现有 CUDA PyTorch；`requirements-web.txt` 不安装或替换 torch。

## 使用

选图或拖入 → 点击“让蛙去水印” → 查看真实排队/推理状态 → 滑动或并排比较 → 下载 PNG。

- PNG/JPEG/WebP，不透明、非动画，最多 12 MB、400 万像素、最长边 8192。
- 输入按 EXIF 方向规范化，删除元数据，另存 PNG 供推理与对比；不裁切画面。
- 当前模型内部仍是 **256×256 全局缩放**；输出回到原图的视觉方向及尺寸。大图细小水印可能效果不理想。
- 沿用现有模型预测的背景和掩码融合，不新增滤镜、切块或人工掩码。
- 一次只做一个模型推理，等待队列最多 4 个；队列满返回可重试提示。
- 完成后的临时文件闲置约 15 分钟后清理；可手动清除。重启/停止服务后任务不保留。正常停止会清理临时目录；强制杀死进程或机器异常断电时，系统临时目录可能遗留文件。
- 心情、收藏保存在浏览器；上传图片和结果不写入 localStorage。

## 更新权重

停止服务，将 `--weights` 改为新的 `best-weights.pt`，再启动。也可在停止后用新文件替换原权重路径。

必须是同一架构导出的 `slbr-fourier-inference-v1` 权重、同一参考提交。严格加载失败时不能改成 `strict=False` 强行上线。模型每个进程加载一次，运行中不自动热换权重。

## 服务器使用

同一包也支持 Ubuntu 22.04 的 Python 3.10。先把程序和权重传到服务器；不是只传权重。详见 `docs/SERVER.md`。

此前的 Sites 链接只能用于主题与页面预览：其静态托管环境没有运行这份 Python/PyTorch 服务，那里会如实显示“尚未连接模型”。真正使用应访问运行本应用的电脑或服务器地址。

## 检查与范围

- 权重 495 项严格匹配；SLBR/Fourier/_reference 结构未改动，见 `docs/INTEGRATION.md`。
- 已在本执行环境 PyTorch 2.5.1 CPU、4 推理线程下验证：真实权重处理、API 下载、与独立推理逐像素一致、单次加载、有限排队、访问码与清理。
- 当前无法访问你的 RTX 4060 或腾讯云服务器，未宣称这两台设备已验证。
- 网页预览基础服务当前不可用，真实浏览器布局、拖拽和移动端视觉验收尚未完成；已检查 JavaScript 语法、DOM 引用及静态资源。
- `reports/*.json` 记录实际检查结果。合成测试图仅检查链路，不衡量去水印质量。
- 训练日志已读，但未提供训练配置、划分文件和配对评估数据，因此没有重跑训练/数据验收/质量评估，也未修改训练方法。

可选重复检查（正常使用不必执行）：安装 `requirements-check.txt`，运行 `python scripts/check_app.py --weights <你的权重路径> --device cpu`。

## 素材

页面角色沿用已取得的原版转载图，没有恢复使用 AI 重绘。部分表情为漫画局部显示，像素较少，不代表高清源素材。来源与访问日期见 `asset-sources.json`。角色相关权利归原权利人，原始透明源文件及网页/商业使用授权未核实，本站非官方合作项目。
