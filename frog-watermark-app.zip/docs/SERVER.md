# 腾讯云 Ubuntu 22.04：同一应用的 CPU 运行方式

当前没有直接登录/修改你的腾讯云服务器。以下是待你执行的部署说明；4 核、约 4 GB 内存是否满足实际等待时间仍需在该服务器实测。不要将当前执行环境 CPU 的时间当作服务器或 RTX 4060 的速度。

## 1. 上传

将压缩包内容上传并解压到 `/opt/frog-watermark-app`；另将自己的 `best-weights.pt` 放到 `/opt/frog-watermark-app/weights/best-weights.pt`。数据集、训练环境、`last.pt` 不需要上传。

## 2. 安装并运行

```bash
sudo apt-get update
sudo apt-get install -y python3-venv
cd /opt/frog-watermark-app
python3 -m venv .venv
.venv/bin/python -m pip install torch==2.5.1+cpu --index-url https://download.pytorch.org/whl/cpu
.venv/bin/python -m pip install -r requirements-web.txt
.venv/bin/python -m wmr.web --weights weights/best-weights.pt --device cpu --host 127.0.0.1 --port 8080 --cpu-threads 4
```

先在服务器另一终端运行 `curl http://127.0.0.1:8080/api/health`，确认 `ready: true`，再通过页面处理实际图片。模型不需要 GPU 才能运行，但 CPU 的等待时间需要实测。

## 3. 对外访问

建议让已有 Nginx/HTTPS 站点代理到 `127.0.0.1:8080`，**整个站点（包括 /api）代理到同一个 Python 进程**。示例 location：

```nginx
location / {
    client_max_body_size 12m;
    proxy_pass http://127.0.0.1:8080;
    proxy_set_header Host $host;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_read_timeout 120s;
}
```

域名、证书、腾讯云安全组及现有 Nginx 配置尚未取得，不能把示例当作已经完成的外网部署。后续拿到你的实际站点配置再给出准确修改命令，不覆盖现有站点。

少量受邀使用可设置环境变量 `WMR_ACCESS_TOKEN` 为自己的随机英文数字通行码再启动。网页会自动出现通行码输入框，任务提交/查询/图片下载/删除接口均校验该码。通过 HTTPS 使用通行码；不把密钥写进前端或 Git。

默认绑定 127.0.0.1。临时直接测试可使用 `--host 0.0.0.0`，但这会开放监听，且仍需服务器防火墙/安全组允许访问。不是添加该参数就自动获得公网访问。

## 4. 常驻

确认单次实际处理和资源占用后，再配置 systemd。保持 **一个应用进程**，不要设置多个 Uvicorn worker，每个 worker 都会单独加载模型并拥有独立任务队列。

本版队列在进程内，重启会清理临时目录并丢弃任务。每张图保留原图尺寸，输出 PNG；下载后请检查结果再使用。机器内存或速度不足时先调整接入负载，不暗中改模型结构或推理分辨率。
