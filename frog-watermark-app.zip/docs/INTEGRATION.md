# 模型与工程接入核验（2026-10-23）

## 输入材料与未取得材料

已检查：用户上传的 server-source(1).zip、best-weights.pt、history.jsonl。ZIP 实际仅包含 wmr、reference-lock.json、requirements.txt，未包含训练 configs、原项目 docs/AGENTS、run-config 或数据集/划分表。本项目 AGENTS.md 根据会话中已确认约束整理，不冒充上传原文件。

本轮不训练、不更换损失、不宣称已复测验证集结果。训练日志 39 行，最高记录为 epoch 37：PSNR 38.05465504074097、SSIM 0.9860688043236733、watermark_mae 0.02400329002691433、background_mae 0.000571568161903997、mask_iou 0.7654623273070902。导出文件只带 format/reference_commit/model，**没有 epoch 标签**；无法单靠导出元数据证明它一定对应第 37 轮。

权重 SHA256：d0a89c54d6bc16f798172a7d35804951d74c4d85f3b9d63ad7f2b9718f19aa5b。

## 参考方法 → 项目模块 → 代码位置

| 机制 | 本项目实际实现 | 位置及对应关系 |
|---|---|---|
| SLBR 编码与共享解码 | 原上传实现，shared_depth=1、blocks=3、long_skip=True | wmr/model.py: build_model；wmr/_reference/resunet.py: CoarseEncoder、SharedBottleNeck、SLBR |
| 掩码与背景粗恢复 | MBE/SMR、k_center=2、k_refine=3、k_skip_stage=3 | wmr/_reference/blocks.py；resunet.py: CoarseDecoder；model.py 参数构建 |
| 精细恢复与跨尺度融合 | 完整 Refinement、3 个 CFFBlock | wmr/_reference/resunet.py: Refinement；未删减或替代 |
| 项目 Fourier 改进 | d3 低分辨率特征的频域残差 | wmr/fourier.py；model.py: inject_fourier、build_model 注册的 forward hook |
| FP32 数值策略 | SMR 和 refinement 退出 FP16 autocast 的原包装 | wmr/model.py: smr_forward_fp32、refinement_forward_fp32 |
| 权重 | weights_only=True + strict=True | wmr/checkpoint.py: load_export；495 项全匹配 |
| 单图推理 | RGB → 256² 双线性缩放 → 网络 → 背景/掩码分别上采样 → 与原图混合 | wmr/infer.py: Predictor.process |
| 网页处理 | 单实例 Predictor + 一个推理线程 + 有限队列；不复制推理算法 | 新增 wmr/web.py: create_app |
| 原图对齐 | API 层 EXIF 转正、拒绝非透明决策外输入、保存 canonical PNG | wmr/web.py: canonicalize；网络输入仍由 Predictor 原流程处理 |
| 交互 | 真上传、轮询真实状态、读取原图/结果并比对与下载 | frontend/workbench.js；不存在前端滤镜去水印或假进度百分比 |

SLBR 官方项目来源：https://github.com/bcmi/SLBR-Visible-Watermark-Removal ，锁定提交 47c665f1855ab6624cd52b28cefa797a9c8b96f7。本轮是对上传文件与锁定哈希的核对，未另外重新下载官方仓库。网络原文版本和授权不能仅由仓库公开推断。

## 核心结构与数据流

在 256×256 单图输入下：Fourier 分支输入/输出均为 [1,128,64,64]。128→32 的 1×1 卷积降维，rFFT2 得到 [1,32,64,33] 复数频谱；实虚拼接为 64 通道，经 1×1 卷积与 GELU，重组复数并在 DC/Nyquist 边界列投影为共轭对称，irFFT2 回到 64×64，再 32→128 升维，以可学习 gamma 残差融合。它是原项目假设性改进，不因此宣称优于基础模型或具有论文新颖性。

实载参数共 21,403,306；Fourier 12,353。gamma 从上传权重读取为约 0.21158628。release-check 记录实际参与推理的尺寸与非零残差；这不等同于改进有效性的对照证据。

## 具体改动与影响

- model.py、fourier.py、_reference、checkpoint.py、data.py、losses.py、train.py、metrics.py 等上传代码保持原样。文件级差异记录在 reports/source-diff.json。
- infer.py **只增加非有限数检查**：在转换 uint8 前若结果含 NaN/Inf 则明确失败，避免静默输出黑图。正常有限结果的数学操作不变；API 与独立 Predictor 像素一致检查通过。
- 新增 web.py：规范化 EXIF、格式/大小检查、任务管理、一次加载、串行推理、图片下载与定时清理。
- 非透明 alpha 延续上传 read_rgb 的拒绝策略，未擅自白底合成；WebP/PNG 的透明索引也会检查。
- 服务器显式单进程。上限为 1 个推理、4 个等待、12 个包含完成结果在内的任务；文件 12 MiB、400 万像素、最长边 8192。
- 没有加入切块、填边推理、更高分辨率、量化、ONNX 或 TensorRT；这些会改变与现有结果的关系，本轮未采用。

## 验证证据与限制

见 reports/model-check.json、api-check.json、queue-check.json、release-check.json。当前环境 CPU 真权重可加载并处理。正常推理、无效输入拒绝、结果下载、单次模型加载、队列满 429、可选通行码、结果清理都已检查。

首次合成链路样例的 256² 模型前向约 1.24 秒，仅对应本执行环境、4 个 CPU 线程和一次请求，未预热，不是论文速度或稳定延迟，也不是你的腾讯云/4060 实测。真实角色 JPG 的链路检查仅确认可读取并返回正确尺寸，没有干净配对背景可计算恢复质量。

Python 3.10 的依赖 wheel 解析已通过；Starlette 固定为兼容 3.10 的 1.7.0。实际执行环境为 Python 3.12，未伪称在 Windows 3.11/Ubuntu 3.10 上执行过。

受管浏览器预览基础设施不可用，未执行真实浏览器交互与移动端截图检查。已检查 HTML 资源/锚点/DOM 引用和 JS 语法；接口检查不能替代浏览器 QA。

官方接口参考（2026-10-23 访问）：https://fastapi.tiangolo.com/advanced/events/ （模型生命周期）；https://fastapi.tiangolo.com/tutorial/request-files/ （文件处理背景）。本服务为限流量的原始图片请求体，不需要 multipart 解析器；普通用户通过页面上传即可。

## 部署边界

Sites 上只发布前端主题，没有把 PyTorch 或用户权重放进其静态目录/Git。API 必须由本包在用户本机/腾讯云等 Python 主机运行。当前没有腾讯云登录权限、域名或反代配置，未宣称已完成公网推理服务上线。

角色与原代码/预训练权重的公开可读性不代表允许商业服务或再分发。继续沿用来源记录；没有新增“已获官方授权”的声明。
