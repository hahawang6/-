import hashlib
import json
import weakref
from pathlib import Path
from types import SimpleNamespace
import torch
from .fourier import FourierResidual

REFERENCE_COMMIT = "47c665f1855ab6624cd52b28cefa797a9c8b96f7"


def verify_reference():
    root = Path(__file__).parent / "_reference"
    if not (root / "installed.json").exists():
        raise RuntimeError("Run scripts/fetch_reference.py first; no substitute model is supplied.")
    record = json.loads((root / "installed.json").read_text())
    if record["commit"] != REFERENCE_COMMIT:
        raise RuntimeError("Unexpected reference version")
    for name, digest in record["files"].items():
        if hashlib.sha256((root / name).read_bytes()).hexdigest() != digest:
            raise RuntimeError(f"Modified reference file requires review: {name}")


def inject_fourier(module, inputs, outputs):
    # Down3 returns (x, before_pool). Refinement consumes before_pool as d3.
    x, d3 = outputs
    return x, module._fourier_owner()(d3)


def build_model():
    verify_reference()
    from ._reference.resunet import SLBR
    args = SimpleNamespace(bg_mode="res_mask", mask_mode="res", sim_metric="cos",
                           k_center=2, project_mode="simple", use_refine=True,
                           k_refine=3, k_skip_stage=3)
    model = SLBR(args=args, shared_depth=1, blocks=3, long_skip=True)
    model.refinement.fourier = FourierResidual()
    # A weak reference avoids duplicate parameter registration; call Module.__call__
    # normally so hooks and instrumentation also observe the actual Fourier branch.
    model.refinement.down3._fourier_owner = weakref.ref(model.refinement.fourier)
    model.refinement.down3.register_forward_hook(inject_fourier)
    return model


def load_base_weights(model, path):
    """Trusted, official local checkpoint. Require exact base keys and shapes."""
    obj = torch.load(path, map_location="cpu", weights_only=True)
    state = obj.get("state_dict", obj)
    clean = {}
    for key, value in state.items():
        parts = [part for part in key.split(".") if part != "module"]
        key = ".".join(parts)
        if key in clean:
            raise ValueError("Duplicate checkpoint key after DataParallel normalization")
        clean[key] = value
    current = model.state_dict()
    added = {k for k in current if k.startswith("refinement.fourier.")}
    if set(clean) != set(current) - added:
        raise ValueError(f"Base checkpoint mismatch: missing={sorted(set(current)-added-set(clean))}; "
                         f"unexpected={sorted(set(clean)-set(current))}")
    mismatches = [k for k in clean if clean[k].shape != current[k].shape]
    if mismatches:
        raise ValueError(f"Checkpoint shape mismatch: {mismatches}")
    current.update(clean)
    model.load_state_dict(current, strict=True)
    return {"loaded_base_keys": len(clean), "new_fourier_keys": sorted(added)}
