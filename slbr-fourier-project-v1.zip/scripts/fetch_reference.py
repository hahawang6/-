"""Fetch exact upstream sources; verify hashes before documented compatibility patches."""
import argparse
import hashlib
import json
import urllib.request
from pathlib import Path


def install(project, source_dir=None):
    lock = json.loads((project / "reference-lock.json").read_text())
    dest = project / "wmr" / "_reference"
    dest.mkdir(exist_ok=True)
    manifest = {}
    for name, digest in lock["files"].items():
        if source_dir:
            raw = (Path(source_dir) / name).read_bytes()
        else:
            url = ("https://raw.githubusercontent.com/bcmi/SLBR-Visible-Watermark-Removal/"
                   + lock["commit"] + "/" + name)
            with urllib.request.urlopen(url, timeout=90) as response:
                raw = response.read()
        actual = hashlib.sha256(raw).hexdigest()
        if actual != digest:
            raise RuntimeError(f"Reference hash mismatch: {name}: {actual}")
        text = raw.decode("utf-8").replace("\r\n", "\n")
        text = text.replace("from src.networks.blocks import", "from .blocks import")
        text = text.replace("from src.utils.model_init import", "from .model_init import")
        # Imports unused anywhere in the corresponding source; no layers removed.
        for line in ("import torchvision\n", "import numpy as np\n", "import cv2\n",
                     "import scipy.stats as st\n", "import itertools\n"):
            text = text.replace(line, "")
        text = text.replace("shape[2:][::-1]", "shape[2:]")
        text = text.replace("    def __call__(self, x):\n        return self.forward(x)\n", "")
        target = dest / Path(name).name
        target.write_text(text, encoding="utf-8", newline="\n")
        manifest[target.name] = hashlib.sha256(target.read_bytes()).hexdigest()
    (dest / "__init__.py").write_text("")
    (dest / "installed.json").write_text(json.dumps({"commit": lock["commit"], "files": manifest}, indent=2))
    print("Fixed reference installed and hash-verified:", lock["commit"])


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--source-dir", type=Path)
    args = p.parse_args()
    install(Path(__file__).resolve().parents[1], args.source_dir)
