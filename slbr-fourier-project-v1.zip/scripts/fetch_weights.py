"""Download only the CLWD checkpoint linked by the official SLBR README."""
import hashlib
import shutil
import urllib.request
from pathlib import Path

URL = "https://drive.google.com/uc?export=download&id=1uTCzubnWZtu3HIXaK8xsXX-7x302ss13"
SHA256 = "be5c0a89513803c8ce56b1768e0c6296900f6ef76df8cbda12900324f9b1caf9"


if __name__ == "__main__":
    root = Path(__file__).resolve().parents[1]
    target = root / "weights" / "slbr-clwd-official.pth.tar"
    target.parent.mkdir(exist_ok=True)
    if target.exists():
        if hashlib.sha256(target.read_bytes()).hexdigest() != SHA256:
            raise ValueError("Existing checkpoint has unexpected SHA256; do not overwrite silently")
    else:
        temporary = target.with_suffix(".download")
        with urllib.request.urlopen(URL, timeout=120) as response:
            if "text/html" in response.headers.get("Content-Type", ""):
                raise RuntimeError("Download returned HTML instead of weights; no checkpoint installed")
            with temporary.open("wb") as handle:
                shutil.copyfileobj(response, handle)
        if hashlib.sha256(temporary.read_bytes()).hexdigest() != SHA256:
            raise RuntimeError("Downloaded weight hash mismatch; no checkpoint installed")
        temporary.replace(target)
    print("Official checkpoint verified:", target)
    print("Download does not establish permission for use or distribution; see docs/STRUCTURE.md")
