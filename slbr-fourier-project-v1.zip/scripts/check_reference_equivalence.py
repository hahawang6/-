"""Developer check against provided upstream clone; not an extra trained model."""
import argparse, ast, json, sys
from pathlib import Path
from types import SimpleNamespace
import torch
from torch import nn
from torch.nn import functional as F
from torchvision import models
from wmr.model import build_model
from wmr.losses import SLBRObjective, relative_l1

def selected(path, names):
    tree=ast.parse(path.read_text())
    return ast.unparse(ast.Module(body=[n for n in tree.body if getattr(n,"name",None) in names],type_ignores=[]))

p=argparse.ArgumentParser();p.add_argument("--upstream",required=True);p.add_argument("--output",required=True)
args=p.parse_args();up=Path(args.upstream);torch.set_num_threads(4);torch.manual_seed(7)
model=build_model().eval()
from wmr._reference.resunet import SLBR
baseline=SLBR(args=model.args,shared_depth=1,blocks=3,long_skip=True).eval()
base={k:v for k,v in model.state_dict().items() if not k.startswith("refinement.fourier.")}
baseline.load_state_dict(base,strict=True)
model.refinement.fourier.gamma.data.zero_()
with torch.no_grad():
    x=torch.rand(1,3,256,256)
    actual=model(x);expected=baseline(x)
    for a,b in zip(actual[0]+actual[1],expected[0]+expected[1]):torch.testing.assert_close(a,b,rtol=0,atol=0)
    # Exercise the documented rectangular interpolation fix without shrinking channels.
    rect=model(torch.rand(1,3,64,96));assert rect[0][0].shape==(1,3,64,96)
    target=torch.rand_like(x);mask=torch.zeros_like(x[:,:1]);mask[:,:,80:160,80:160]=1
namespace={"torch":torch,"nn":nn,"F":F,"models":models,"l1_relative":relative_l1,
           "resize_to_match":lambda a,b:F.interpolate(a,b.shape[-2:],mode="bilinear",align_corners=False)}
code=selected(up/"src/utils/losses.py",{"MeanShift","VGG16FeatureExtractor","VGGLossX"})
code=code.replace(".cuda()", ".to('cpu')")
exec(code,namespace)
ref_vgg=namespace["VGGLossX"](style=True)
objective=SLBRObjective().eval()
with torch.no_grad():
    c,s=objective.vgg(x,target);v=ref_vgg(x,target,mask)
    torch.testing.assert_close(c,v['content'],rtol=2e-6,atol=1e-6)
    torch.testing.assert_close(s,v['style'],rtol=2e-6,atol=1e-6)
import types
iou_ns={};exec((up/"pytorch_iou/__init__.py").read_text(),iou_ns)
namespace.update({"pytorch_iou":types.SimpleNamespace(IOU=iou_ns["IOU"]),
                  "VGGLoss":lambda *a,**kw:ref_vgg,"is_dic":lambda x:isinstance(x,list)})
exec(selected(up/"src/models/SLBR.py",{"Losses"}),namespace)
params=SimpleNamespace(lambda_content=.25,lambda_style=.25,lambda_iou=.25,lambda_primary=.01,sltype='vggx')
reference=namespace["Losses"](params,'cpu',lambda x:x,lambda x:x)
with torch.no_grad():
    terms=reference(x,actual[0],target,actual[1],mask)
    ours=objective(actual,target,mask)
    ref_total=2*(terms[0]+terms[1])+terms[2]+terms[3]
    torch.testing.assert_close(ours['total'],ref_total,rtol=2e-6,atol=1e-5)
result={"network_gamma_zero_exact_equal_256":True,"rectangular_forward_64x96":True,
        "vgg_content_and_style_match_reference":True,"complete_objective_matches_reference":True,
        "loss_actual":ours['total'].item(),"loss_reference":ref_total.item(),
        "scope":"Arithmetic equivalence checks using random inputs; not effect comparison or training."}
Path(args.output).write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
