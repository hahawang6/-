# 实现依据与对应关系（实现前固定）

参考：Liang 等，Visible Watermark Removal via Self-calibrated Localization and Background Refinement，ACM MM 2021；官方提交47c665f1855ab6624cd52b28cefa797a9c8b96f7。
本项目采用固定发布代码的网络和训练目标，加一个Fourier分支。不是严格论文复现，不承诺复现论文成绩。

| 参考机制 | 项目实际代码 | 正式规格 |
|---|---|---|
| CoarseEncoder | wmr/_reference/resunet.py:CoarseEncoder | blocks=3；32/64/128；BN；三级pool |
| SharedBottleNeck | 同文件:SharedBottleNeck | shared_depth实际2；256/512；dilation1/2/5；共享上采样+两任务ECA |
| SMR与两中心校准 | wmr/_reference/blocks.py:SMRBlock,SelfAttentionSimple | 三尺度；k_center=2；不替换为普通卷积分割 |
| MBE恢复 | 同文件:MBEBlock | 三尺度；校准mask.detach引导；原门控残差 |
| 跨阶段及细化 | resunet.py:Refinement | 三个decoder skip；32/64/128；三个CFF |
| Fourier | wmr/fourier.py；wmr/model.py | refinement.down3输出d3与首个CFF之间；128→32→rFFT2→64实虚通道1x1+GELU→irFFT2→128；gamma=1e-3 |
| 多尺度监督 | wmr/losses.py | 区域相对L1、粗/细恢复、GT背景融合L1、三尺度primary/calibrated BCE与IoU |
| 感知及style | wmr/losses.py | 预训练VGG16前三组features；ImageNet归一化；冻结；三尺度L1与Gram |
| 自动推理融合 | wmr/infer.py | 仅预测mask融合输入；禁止用GTmask恢复输出 |
| 配对读取 | wmr/data.py | 清单、同步resize/flip、RGB[0,1]、二值mask；无伪造alpha标签 |

256×256输入：encoder skip依次32×256²/64×128²/128×64²，输出128×32²；shared最深512×16²，双任务输出256×32²；coarse decoder依次128×64²/64×128²/32×256²，coarseRGB与mask全尺寸；refinement输入coarse融合RGB+预测mask，特征32×256²/64×128²/128×64²；三个CFF保留同三尺度，拼接224通道输出RGB。

相对参考的明确差异：
1. Fourier为本项目探索假设，不称原创或已证实改善；不改变参考主干宽度/深度。
2. 删除纯未用import、修正包路径；不删未使用的声明参数，保持权重键。
3. 三处size=shape[2:][::-1]改为shape[2:]，避免非方形尺寸颠倒；方形输入等价。
4. DownConv.__call__改为forward（移除绕过Module机制的自定义__call__），计算体不变，恢复hook工具可观测性。
5. 损失按发布代码独立实现；IoU分母clamp_min防空区域NaN，非空时等价。VGG改用设备无关API，FP32损失，FFT FP32。
6. dataset由CLWD改LOGO-Multi；Pillow双线性resize不同于参考OpenCV线性插值的像素细节。基于原脚本采用方形resize和同步水平翻转；不是保持比例的训练协议。
7. mask标签严格二值，不把wm或alpha作必要输入；训练GTmask融合仅用于参考损失，推理用预测mask。
8. 检查点与训练循环重写以保存全部优化器等状态；不沿用参考BasicModel未实际使用的父优化器。
9. 参考声明但无forward梯度：每级SMR.refine_branch及self_calibrated.k_weight，保留并明确报告；其他无梯度必须排查。

授权：未找到SLBR仓库整体LICENSE或明确权重授权。获取源码/权重不等于可任意修改、分发或商用；本包不附作者源码或权重，不替作者授权。公开/商业分发前仍需解决该项。依赖及VGG权重分别遵循各自条款，不能以本包替代授权说明。
