# 2026-10-21 精度修复说明

依据：用户同一真实样本的CUDA报告（RTX4060 Laptop，torch2.5.1+cu124，256，batch1）。FP32输出与全部损失有限，total1.8950796；FP16在第一个CFF的down2.model.conv1输出769个Inf，输入max43392且有限。首个观测异常位于卷积输出，不能由此证明Fourier对激活幅值没有影响，也不能外推整个数据集稳定。

修改wmr/model.py：
- 完整Refinement入口关闭autocast并将input/coarseRGB/mask/decoder特征显式转FP32。原Refinement.forward、三CFF、所有skip/通道与Fourier保留。
- SMR入口同样FP32，保留原SMR.forward与sigmoid/BCE；原因是BCE概率的反向梯度转回half仍可能溢出，仅loss.float不足。这是代码审查确定的AMP边界问题，不冒充本次首错。
- 不用nan_to_num/clamp特征幅值/删除分支/替换网络。模型训练与独立推理共用同一build_model。权重键与参数数量不变，无须重新下载或改参考文件。
- preflight记录精度策略与loss-scale尝试；从scale256最多4次自动回退，只有有限梯度才更新一次参数。回退时恢复BN buffers和清梯度，避免累积副作用；不会跳过非有限损失。正式训练scaler自适应策略未改变。

代价：相对原全局AMP可能增加显存与延迟，GPU大小和耗时待本机检查；没有默认降低分辨率或batch，也没承诺正式microbatch2可用。

已执行CPU受影响检查：256输入新旧FP32逐项严格相等；权重键不变；64输入全部活动参数反向有限且输入梯度连通；见refinement-fp32-check.json。CPU环境无法执行原生half转换（cpuinfo后端失败），不能替代CUDA测试。

用户只需覆盖此补丁后重跑原GPU preflight一次，结果写runs/preflight-gpu-v2.json，不重装、不重新取资源、不重做数据审计。该检查不是正式训练。

官方依据：https://docs.pytorch.org/docs/2.14/amp.html （局部关闭autocast需显式输入转型；BCE从half转float不能消除反向的half边界风险；访问2026-10-21）。实际代码API仍在torch2.5.1 CPU上运行检查，不要求升级torch。
