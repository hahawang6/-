# SLBR＋Fourier 本地项目：模型与训练阶段交付

## 本包是什么
完整固定参考SLBR的接入代码、单个Fourier残差分支、配对数据加载、全套发布代码损失、训练/验证/断点恢复、独立权重导出、CLI推理和独立评估。不是简易双解码器。页面尚未开发，待模型训练与评估后增加。
本包不附作者源码或权重；脚本从原始地址获取并校验固定版本。安装后wmr/_reference为完整参考网络，不能省略该安装步骤。源码可访问不代表授权明确；详见docs/STRUCTURE.md。

## Windows安装（项目根目录运行）
现有Python3.11与.venv继续使用。压缩包解压到D:\AIProjects\watermark-removal，保留既有data目录。

```powershell
& ".\.venv\Scripts\python.exe" -m pip install torch==2.5.1 torchvision==0.20.1 --index-url https://download.pytorch.org/whl/cu124
& ".\.venv\Scripts\python.exe" -m pip install -r requirements.txt
& ".\.venv\Scripts\python.exe" scripts/fetch_reference.py
& ".\.venv\Scripts\python.exe" scripts/fetch_weights.py
& ".\.venv\Scripts\python.exe" -c "import torch; print(torch.__version__, torch.cuda.is_available()); print(torch.cuda.get_device_name(0))"
```
固定2.5.1/0.20.1用于与本包实际检查版本对应，不声称为最新；官方仍列出对应Windows CUDA12.4轮子。通常不需要额外安装CUDA Toolkit；以实际torch.cuda检查为准。驱动560.94与RTX4060尚未在本环境直接测试。原项目PyTorch1.x依赖列表不直接照装。
源码脚本需访问raw.githubusercontent.com，官方模型需访问Google Drive，VGG16需访问download.pytorch.org。网络失败会报错，不会换成随机权重或普通网络。VGG文件约528MiB，官方SLBR文件85,707,015字节；下载时间依网络。

## 当前应执行的一次必要检查
先退出不必要的GPU负载。以下在真实数据上检查正式网络、256输入、batch1；只做一次优化步，检查权重保存和独立推理，属于调试，不是正式训练或质量证明：

```powershell
& ".\.venv\Scripts\python.exe" -m wmr.preflight --device cuda --size 256 --batch 1 --data-root data/raw/LOGO-Multi --base-weights weights/slbr-clwd-official.pth.tar --output runs/preflight-gpu.json
```
报告peak包含重新加载检查，不能当作纯模型推理显存。这里不提供可信的GPU时间估算，CPU检查时间也不能转成4060速度。OOM时报告错误，不能自动删层降宽度。AMP数值异常同样停止排查。

## 正式训练提案（尚未批准，不会自动执行）
configs/train-proposal.json中approved_for_formal_training=false，这是配置确认门槛，不是模型占位实现。
- 初始化：已核对匹配的官方CLWD权重，490个基础键完整匹配；仅新增5个Fourier权重键随机初始化，gamma=1e-3。
- 单模型联合微调，完整主干不冻结；输入256x256、训练同步水平翻转、RGB[0,1]、mask最近邻。
- 建议物理batch2、累积4，常规更新有效batch8。参考脚本真实batch8；累积不等同BN实际batch8，最后不足8的更新按实际样本加权。这是须确认的训练协议偏差，未承诺8GB装得下。
- 建议Adam(.9,.999)，全模型lr1e-4，第65个epoch后乘.1，100epoch预算上限。参考发布脚本lr1e-3；改小10倍针对已有权重的联合微调，属于本项目方案而非原协议。论文与代码betas本有差异，按代码固定。
- 粗阶段使用AMP，但完整SMR与完整Refinement固定FP32；FFT与全部损失FP32（依据本机溢出报告修复，见docs/AMP_FIX.md）；没有默认启用激活检查点，不能称它已验证。若资源不足，优先检查负载并说明可选checkpoint措施，不静默改变网络或配置。
- 10389训练样本，每epoch5195个物理batch、1299个优化更新；100epoch约519500个物理batch、129900个更新（不含AMP溢出跳过），验证1000张/epoch。
- 每epoch验证，按预测mask自动融合输出的平均逐图PSNR选best-weights.pt，记录SSIM/区域MAE/maskIoU。测试集不参与选择。
- 断点为epoch边界；中途打断只能恢复到最后完成的epoch。保存四个实际优化器、调度器、scaler、RNG、数据清单哈希和配置，不声称任意batch精确恢复。
- 在硬件检查后确认配置，再将approved改true。正式训练命令如下，目前执行会明确拒绝未批准配置。

```powershell
& ".\.venv\Scripts\python.exe" -m wmr.train --base-weights weights/slbr-clwd-official.pth.tar
# 恢复自己的可信训练文件：
& ".\.venv\Scripts\python.exe" -m wmr.train --resume runs/slbr-fourier-v1/last.pt
```
预算不能用“100轮”保证充分。依据训练/验证曲线、伪影和残留判断过拟合/训练不足：训练持续降而验证恶化说明泛化问题；两者仍明显改善至预算结束提示可能未收敛；两者平台也可能是数据/优化问题，并非直接证明模型能力上限。不默认追加搜索/新模型。
耗时算式：100×(5195×实测平均训练microbatch秒数＋1000×验证单图秒数)＋保存/I/O开销。需正式条件下稳定窗口实测；一次preflight包含初始化和导出，不可直接外推。

## 独立推理与训练后评估
正常使用只加载导出权重，不启动训练。只加载自己或可信来源权重。

```powershell
& ".\.venv\Scripts\python.exe" -m wmr.infer --weights runs/slbr-fourier-v1/best-weights.pt --input examples/input.png --output outputs/result.png
& ".\.venv\Scripts\python.exe" -m wmr.evaluate --weights runs/slbr-fourier-v1/best-weights.pt
```
当前独立推理先将整图resize到256方形，预测RGB和mask，再回到原尺寸与原始RGB融合。输出尺寸还原不等于原生高分辨率恢复；细小水印可能丢失，几何变形可能影响效果。尚不含切块、去接缝或高分辨率增强，不能声称支持任意分辨率高质量。
验证/测试指标定义在256缩放域；CLI原尺寸融合是展示/使用路径，原尺寸质量未经评估，不能将缩放域分数当作它的成绩。两者共享模型和预测mask融合规则。
PSNR按逐图平均，SSIM为RGB11x11 sigma1.5有效卷积；与不同实现论文不能直接等同。水印区MAE测目标差异不能单独区分残留/背景损伤；真实无配对图只作观察。

## 已执行证据与限制
查看docs/preflight-cpu.json、reference-equivalence.json、data-loader-check.json、official-weights-check.json。
- CPU完整网络64输入：全部活动参数有梯度；9个预期无梯度参考参数保留；Fourier梯度非零；三CFF执行；优化、四优化器保存恢复、严格权重重载与独立Predictor输出成功。
- 256输入关闭新增分支：与固定参考网络逐项严格相等；非方形64x96前向成功。
- 发布代码完整损失及VGG内容/style分别对照通过；这是数值计算核对，不是新增基线训练或效果对比。
- 合成文件加载检查通过；真实本机数据加载及Windows/CUDA/AMP尚未执行。
- 官方权重已下载并核对完整基础键与形状，未在LOGO-Multi上评价其效果。
- 未训练、未证明Fourier有收益、未实测4060显存与速度、未解决整体授权，不称已训练可用产品。

## 数据边界
按用户已有v1清单训练10389/验证1000/测试2000，raw不修改；测试背景同名来源已排除训练。无需重复全量解码审计。
8组抽样input/natural alpha均255、mask仅0/255；loader遇其他情况明确报错。natural仍可能含原有文字、水印或标志；任务目标为去掉本次合成水印，不能据此承诺识别任意真实水印。无法证明水印身份互斥或完全无近似背景。

## 来源（访问/核验日期2026-10-21）
- https://github.com/bcmi/SLBR-Visible-Watermark-Removal （固定提交见reference-lock.json）
- https://arxiv.org/pdf/2108.03581
- https://pytorch.org/get-started/previous-versions/ （2.5.1官方配套版本）
- https://drive.google.com/file/d/1uTCzubnWZtu3HIXaK8xsXX-7x302ss13/view （官方README权重）
